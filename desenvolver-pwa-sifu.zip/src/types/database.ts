// Enums
export type ProfileType = 'cidadao' | 'fiscal' | 'gerente';
export type StatusOnline = 'em_campo' | 'escritorio' | 'offline';
export type DenunciaStatus = 'pendente' | 'designada' | 'em_vistoria' | 'aguardando_aprovacao' | 'concluida' | 'arquivada';
export type Prioridade = 'normal' | 'alta' | 'urgente';
export type FotoTipo = 'denuncia' | 'vistoria' | 'relatorio' | 'auto_infracao';
export type FiscalStatusCampo = 'a_caminho' | 'no_local' | 'saiu';
export type StatusAprovacao = 'pendente' | 'aprovado' | 'devolvido';
export type TipoAtividade = 'vistoria' | 'auto_infracao' | 'relatorio' | 'notificacao';
export type TipoNotificacao = 
  | 'nova_denuncia' 
  | 'fiscal_designado' 
  | 'fiscal_a_caminho' 
  | 'fiscal_no_local' 
  | 'relatorio_pendente' 
  | 'auto_pendente' 
  | 'aprovado' 
  | 'devolvido' 
  | 'concluida' 
  | 'mensagem_chat' 
  | 'prazo_vencendo' 
  | 'prazo_vencido';

// Table Types
export interface Profile {
  id: string;
  tipo: ProfileType;
  nome: string;
  matricula?: string | null;
  login_usuario?: string | null;
  telefone?: string | null;
  avatar_initials: string;
  avatar_color: string;
  status_online: StatusOnline;
  latitude_atual?: number | null;
  longitude_atual?: number | null;
  ultima_localizacao_at?: string | null;
  created_at: string;
}

export interface Denuncia {
  id: string;
  protocolo: string;
  denunciante_nome: string;
  denunciante_telefone?: string | null;
  denunciante_anonimo: boolean;
  tipo: string;
  tipo_codigo: string;
  endereco: string;
  ponto_referencia?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  precisao_gps?: number | null;
  descricao: string;
  descricao_audio_url?: string | null;
  status: DenunciaStatus;
  prioridade?: Prioridade | null;
  prazo_sla_horas?: number | null;
  prazo_sla_vence_em?: string | null;
  fiscal_id?: string | null;
  gerente_id?: string | null;
  designada_at?: string | null;
  vistoria_iniciada_at?: string | null;
  concluida_at?: string | null;
  fiscal_latitude_checkin?: number | null;
  fiscal_longitude_checkin?: number | null;
  fiscal_distancia_metros?: number | null;
  fiscal_status_campo?: FiscalStatusCampo | null;
  qrcode_data?: string | null;
  created_at: string;
  updated_at: string;
  // Joined data
  fiscal?: Profile;
  gerente?: Profile;
}

export interface Foto {
  id: string;
  denuncia_id: string;
  uploaded_by?: string | null;
  tipo: FotoTipo;
  url: string;
  url_marca_dagua?: string | null;
  marca_dagua_dados?: {
    data: string;
    hora: string;
    gps?: string;
    protocolo?: string;
    fiscal_nome?: string;
  } | null;
  ordem: number;
  created_at: string;
}

export interface Relatorio {
  id: string;
  denuncia_id: string;
  fiscal_id: string;
  tipo_relatorio: string;
  situacao_encontrada: string;
  providencias_adotadas: string;
  observacoes?: string | null;
  assinatura_url?: string | null;
  assinatura_dados?: {
    data: string;
    hora: string;
    gps_lat?: number;
    gps_lng?: number;
    fiscal_nome: string;
    protocolo: string;
  } | null;
  status_aprovacao: StatusAprovacao;
  gerente_parecer?: string | null;
  aprovado_at?: string | null;
  created_at: string;
  // Joined
  fiscal?: Profile;
  denuncia?: Denuncia;
}

export interface AutoInfracao {
  id: string;
  denuncia_id: string;
  fiscal_id: string;
  infracao_tipo: string;
  valor_base: number;
  grau: string;
  grau_multiplicador: number;
  reincidencia: boolean;
  reincidencia_multiplicador: number;
  valor_total: number;
  valor_editado: boolean;
  fundamento_legal: string;
  prazo_recurso_dias: number;
  observacoes?: string | null;
  status: 'emitido' | 'aprovado' | 'pago' | 'cancelado';
  status_aprovacao: StatusAprovacao;
  gerente_parecer?: string | null;
  aprovado_at?: string | null;
  created_at: string;
  // Joined
  fiscal?: Profile;
  denuncia?: Denuncia;
}

export interface MensagemChat {
  id: string;
  denuncia_id: string;
  remetente_id: string;
  remetente_tipo: 'fiscal' | 'gerente';
  texto: string;
  lida: boolean;
  created_at: string;
  // Joined
  remetente?: Profile;
}

export interface Notificacao {
  id: string;
  destinatario_id?: string | null;
  destinatario_protocolo?: string | null;
  tipo: TipoNotificacao;
  titulo: string;
  mensagem: string;
  denuncia_id?: string | null;
  lida: boolean;
  created_at: string;
}

export interface HistoricoAtividade {
  id: string;
  fiscal_id: string;
  denuncia_id: string;
  tipo_atividade: TipoAtividade;
  descricao: string;
  local_descricao?: string | null;
  quadra?: string | null;
  lote?: string | null;
  valor_ganho: number;
  mes: number;
  ano: number;
  created_at: string;
  // Joined
  denuncia?: Denuncia;
}

// Views
export interface HistoricoEndereco {
  endereco: string;
  total_ocorrencias: number;
  protocolos: string[];
  tipos: string[];
  statuses: string[];
  datas: string[];
}

export interface ProdutividadeFiscal {
  fiscal_id: string;
  mes: number;
  ano: number;
  vistorias: number;
  autos: number;
  total_ganho: number;
  total_atividades: number;
}

export interface DashboardGerente {
  pendentes: number;
  em_andamento: number;
  concluidas: number;
  aguardando_aprovacao: number;
}

// App Types
export interface TipoDenuncia {
  label: string;
  codigo: string;
  icon: string;
  valorMulta: number;
  templateSituacao: string;
  templateProvidencias: string;
  tipoRelatorio: string;
}

export const TIPOS_DENUNCIA: TipoDenuncia[] = [
  {
    label: 'Obra irregular / Sem alvará',
    codigo: 'obra',
    icon: '🏗️',
    valorMulta: 4750,
    tipoRelatorio: 'Construção Irregular',
    templateSituacao: 'Obra em andamento sem apresentação de alvará de construção. Estrutura de alvenaria em fase de [descrever]. Área aproximada de [X]m².',
    templateProvidencias: 'Notificação entregue ao responsável. Prazo de 5 dias úteis para regularização. Embargo da obra até apresentação do alvará.'
  },
  {
    label: 'Descarte irregular de entulho',
    codigo: 'entulho',
    icon: '🗑️',
    valorMulta: 2300,
    tipoRelatorio: 'Descarte de Entulho',
    templateSituacao: 'Constatado descarte irregular de resíduos da construção civil em via pública. Material composto por [descrever]. Volume aproximado de [X]m³.',
    templateProvidencias: 'Auto de infração lavrado. Prazo de 48h para remoção do material. Notificado sobre penalidades por reincidência.'
  },
  {
    label: 'Comércio irregular',
    codigo: 'comercio',
    icon: '🏪',
    valorMulta: 3200,
    tipoRelatorio: 'Comércio sem Licença',
    templateSituacao: 'Estabelecimento comercial em funcionamento sem alvará de licença. Atividade: [descrever]. Horário de funcionamento irregular.',
    templateProvidencias: 'Notificação para apresentação de documentação. Prazo de 10 dias úteis para regularização junto à Vigilância Sanitária e Secretaria de Fazenda.'
  },
  {
    label: 'Poluição sonora',
    codigo: 'som',
    icon: '🔊',
    valorMulta: 1500,
    tipoRelatorio: 'Poluição Sonora',
    templateSituacao: 'Constatada emissão de ruídos acima do permitido. Fonte: [descrever]. Horário da ocorrência: [horário]. Medição aproximada: [X]dB.',
    templateProvidencias: 'Advertência verbal aplicada. Orientação sobre limites de horário e volume. Advertência de multa em caso de reincidência.'
  },
  {
    label: 'Ocupação de calçada',
    codigo: 'calcada',
    icon: '🚧',
    valorMulta: 1800,
    tipoRelatorio: 'Ocupação de Via',
    templateSituacao: 'Constatada ocupação irregular de passeio público. Material/estrutura: [descrever]. Área ocupada aproximada: [X]m². Obstrução de passagem de pedestres.',
    templateProvidencias: 'Notificação para desobstrução imediata. Prazo de 24h para remoção. Alerta sobre apreensão de materiais.'
  },
  {
    label: 'Dano ambiental',
    codigo: 'ambiental',
    icon: '🌳',
    valorMulta: 5000,
    tipoRelatorio: 'Dano Ambiental',
    templateSituacao: 'Constatado dano ambiental. Natureza: [descrever - supressão vegetal, poluição de curso d\'água, etc.]. Área afetada: [X]m².',
    templateProvidencias: 'Embargo da atividade. Encaminhamento para órgão ambiental competente. Notificação sobre responsabilidade de recuperação da área.'
  },
  {
    label: 'Outro',
    codigo: 'outro',
    icon: '📋',
    valorMulta: 1000,
    tipoRelatorio: 'Fiscalização Geral',
    templateSituacao: 'Situação encontrada: [descrever detalhadamente].',
    templateProvidencias: 'Providências adotadas: [descrever].'
  }
];

export const GRAUS_INFRACAO = [
  { label: 'Leve', value: 'leve', multiplicador: 1 },
  { label: 'Grave', value: 'grave', multiplicador: 1.5 },
  { label: 'Gravíssima', value: 'gravissima', multiplicador: 2.5 }
];

export const SEED_FISCAIS: Omit<Profile, 'created_at'>[] = [
  {
    id: 'fiscal-1',
    tipo: 'fiscal',
    nome: 'Roberto Carlos Silva',
    matricula: 'FSC-2847',
    avatar_initials: 'RC',
    avatar_color: '#00D4AA',
    status_online: 'em_campo'
  },
  {
    id: 'fiscal-2',
    tipo: 'fiscal',
    nome: 'Ana Flávia Santos',
    matricula: 'FSC-3102',
    avatar_initials: 'AF',
    avatar_color: '#3B82F6',
    status_online: 'escritorio'
  },
  {
    id: 'fiscal-3',
    tipo: 'fiscal',
    nome: 'João Pedro Lima',
    matricula: 'FSC-2955',
    avatar_initials: 'JP',
    avatar_color: '#FFB020',
    status_online: 'offline'
  }
];

export const SEED_GERENTE: Omit<Profile, 'created_at'> = {
  id: 'gerente-1',
  tipo: 'gerente',
  nome: 'Marcelo Souza',
  login_usuario: 'marcelo.sup',
  avatar_initials: 'MS',
  avatar_color: '#8B5CF6',
  status_online: 'escritorio'
};
