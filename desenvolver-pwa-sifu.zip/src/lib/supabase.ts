import { createClient } from '@supabase/supabase-js';

// Supabase Configuration
// In production, these would be environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://demo.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'demo-anon-key';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
});

// Check if we're in demo mode (no real Supabase connection)
export const isDemoMode = !import.meta.env.VITE_SUPABASE_URL || supabaseUrl === 'https://demo.supabase.co';

// SQL for creating tables (for reference and setup)
export const DATABASE_SCHEMA = `
-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ENUM Types
CREATE TYPE profile_type AS ENUM ('cidadao', 'fiscal', 'gerente');
CREATE TYPE status_online AS ENUM ('em_campo', 'escritorio', 'offline');
CREATE TYPE denuncia_status AS ENUM ('pendente', 'designada', 'em_vistoria', 'aguardando_aprovacao', 'concluida', 'arquivada');
CREATE TYPE prioridade AS ENUM ('normal', 'alta', 'urgente');
CREATE TYPE foto_tipo AS ENUM ('denuncia', 'vistoria', 'relatorio', 'auto_infracao');
CREATE TYPE fiscal_status_campo AS ENUM ('a_caminho', 'no_local', 'saiu');
CREATE TYPE status_aprovacao AS ENUM ('pendente', 'aprovado', 'devolvido');
CREATE TYPE tipo_atividade AS ENUM ('vistoria', 'auto_infracao', 'relatorio', 'notificacao');
CREATE TYPE tipo_notificacao AS ENUM ('nova_denuncia', 'fiscal_designado', 'fiscal_a_caminho', 'fiscal_no_local', 'relatorio_pendente', 'auto_pendente', 'aprovado', 'devolvido', 'concluida', 'mensagem_chat', 'prazo_vencendo', 'prazo_vencido');
CREATE TYPE remetente_tipo AS ENUM ('fiscal', 'gerente');
CREATE TYPE auto_status AS ENUM ('emitido', 'aprovado', 'pago', 'cancelado');

-- Table: profiles
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  tipo profile_type NOT NULL,
  nome TEXT NOT NULL,
  matricula TEXT,
  login_usuario TEXT,
  telefone TEXT,
  avatar_initials TEXT NOT NULL CHECK (char_length(avatar_initials) = 2),
  avatar_color TEXT NOT NULL,
  status_online status_online DEFAULT 'offline',
  latitude_atual FLOAT,
  longitude_atual FLOAT,
  ultima_localizacao_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: denuncias
CREATE TABLE denuncias (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  protocolo TEXT UNIQUE NOT NULL,
  denunciante_nome TEXT DEFAULT 'Anônimo',
  denunciante_telefone TEXT,
  denunciante_anonimo BOOLEAN DEFAULT true,
  tipo TEXT NOT NULL,
  tipo_codigo TEXT NOT NULL,
  endereco TEXT NOT NULL,
  ponto_referencia TEXT,
  latitude FLOAT,
  longitude FLOAT,
  precisao_gps FLOAT,
  descricao TEXT NOT NULL,
  descricao_audio_url TEXT,
  status denuncia_status DEFAULT 'pendente',
  prioridade prioridade,
  prazo_sla_horas INTEGER,
  prazo_sla_vence_em TIMESTAMPTZ,
  fiscal_id UUID REFERENCES profiles(id),
  gerente_id UUID REFERENCES profiles(id),
  designada_at TIMESTAMPTZ,
  vistoria_iniciada_at TIMESTAMPTZ,
  concluida_at TIMESTAMPTZ,
  fiscal_latitude_checkin FLOAT,
  fiscal_longitude_checkin FLOAT,
  fiscal_distancia_metros INTEGER,
  fiscal_status_campo fiscal_status_campo,
  qrcode_data TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: fotos
CREATE TABLE fotos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  denuncia_id UUID REFERENCES denuncias(id) ON DELETE CASCADE NOT NULL,
  uploaded_by UUID REFERENCES profiles(id),
  tipo foto_tipo NOT NULL,
  url TEXT NOT NULL,
  url_marca_dagua TEXT,
  marca_dagua_dados JSONB,
  ordem INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: relatorios
CREATE TABLE relatorios (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  denuncia_id UUID REFERENCES denuncias(id) ON DELETE CASCADE NOT NULL,
  fiscal_id UUID REFERENCES profiles(id) NOT NULL,
  tipo_relatorio TEXT NOT NULL,
  situacao_encontrada TEXT NOT NULL,
  providencias_adotadas TEXT NOT NULL,
  observacoes TEXT,
  assinatura_url TEXT,
  assinatura_dados JSONB,
  status_aprovacao status_aprovacao DEFAULT 'pendente',
  gerente_parecer TEXT,
  aprovado_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: autos_infracao
CREATE TABLE autos_infracao (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  denuncia_id UUID REFERENCES denuncias(id) ON DELETE CASCADE NOT NULL,
  fiscal_id UUID REFERENCES profiles(id) NOT NULL,
  infracao_tipo TEXT NOT NULL,
  valor_base DECIMAL NOT NULL,
  grau TEXT NOT NULL,
  grau_multiplicador DECIMAL NOT NULL,
  reincidencia BOOLEAN DEFAULT false,
  reincidencia_multiplicador DECIMAL DEFAULT 1,
  valor_total DECIMAL NOT NULL,
  valor_editado BOOLEAN DEFAULT false,
  fundamento_legal TEXT DEFAULT 'Art. 127 — Código de Posturas',
  prazo_recurso_dias INTEGER DEFAULT 30,
  observacoes TEXT,
  status auto_status DEFAULT 'emitido',
  status_aprovacao status_aprovacao DEFAULT 'pendente',
  gerente_parecer TEXT,
  aprovado_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: mensagens_chat
CREATE TABLE mensagens_chat (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  denuncia_id UUID REFERENCES denuncias(id) ON DELETE CASCADE NOT NULL,
  remetente_id UUID REFERENCES profiles(id) NOT NULL,
  remetente_tipo remetente_tipo NOT NULL,
  texto TEXT NOT NULL,
  lida BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: notificacoes
CREATE TABLE notificacoes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  destinatario_id UUID REFERENCES profiles(id),
  destinatario_protocolo TEXT,
  tipo tipo_notificacao NOT NULL,
  titulo TEXT NOT NULL,
  mensagem TEXT NOT NULL,
  denuncia_id UUID REFERENCES denuncias(id),
  lida BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table: historico_atividades
CREATE TABLE historico_atividades (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fiscal_id UUID REFERENCES profiles(id) NOT NULL,
  denuncia_id UUID REFERENCES denuncias(id) NOT NULL,
  tipo_atividade tipo_atividade NOT NULL,
  descricao TEXT NOT NULL,
  local_descricao TEXT,
  quadra TEXT,
  lote TEXT,
  valor_ganho DECIMAL DEFAULT 0,
  mes INTEGER NOT NULL,
  ano INTEGER NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Views
CREATE VIEW vw_historico_endereco AS
SELECT endereco, COUNT(*) as total_ocorrencias,
  array_agg(protocolo ORDER BY created_at DESC) as protocolos,
  array_agg(tipo ORDER BY created_at DESC) as tipos,
  array_agg(status::text ORDER BY created_at DESC) as statuses,
  array_agg(created_at ORDER BY created_at DESC) as datas
FROM denuncias
GROUP BY endereco
HAVING COUNT(*) > 0;

CREATE VIEW vw_produtividade_fiscal AS
SELECT fiscal_id, mes, ano,
  COUNT(*) FILTER (WHERE tipo_atividade = 'vistoria') as vistorias,
  COUNT(*) FILTER (WHERE tipo_atividade = 'auto_infracao') as autos,
  SUM(valor_ganho) as total_ganho,
  COUNT(*) as total_atividades
FROM historico_atividades
GROUP BY fiscal_id, mes, ano;

CREATE VIEW vw_dashboard_gerente AS
SELECT
  COUNT(*) FILTER (WHERE status = 'pendente') as pendentes,
  COUNT(*) FILTER (WHERE status IN ('designada', 'em_vistoria')) as em_andamento,
  COUNT(*) FILTER (WHERE status = 'concluida') as concluidas,
  COUNT(*) FILTER (WHERE status = 'aguardando_aprovacao') as aguardando_aprovacao
FROM denuncias;

-- Enable Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE denuncias;
ALTER PUBLICATION supabase_realtime ADD TABLE mensagens_chat;
ALTER PUBLICATION supabase_realtime ADD TABLE notificacoes;
ALTER PUBLICATION supabase_realtime ADD TABLE fotos;

-- Storage Buckets (run in Supabase dashboard)
-- INSERT INTO storage.buckets (id, name, public) VALUES ('fotos-denuncias', 'fotos-denuncias', true);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('assinaturas', 'assinaturas', true);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('relatorios-pdf', 'relatorios-pdf', true);

-- RLS Policies (simplified examples)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE denuncias ENABLE ROW LEVEL SECURITY;
ALTER TABLE fotos ENABLE ROW LEVEL SECURITY;
ALTER TABLE relatorios ENABLE ROW LEVEL SECURITY;
ALTER TABLE autos_infracao ENABLE ROW LEVEL SECURITY;
ALTER TABLE mensagens_chat ENABLE ROW LEVEL SECURITY;
ALTER TABLE notificacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE historico_atividades ENABLE ROW LEVEL SECURITY;

-- Gerente can do everything
CREATE POLICY "Gerente full access" ON denuncias FOR ALL 
  USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND tipo = 'gerente'));

-- Fiscal can see assigned denuncias
CREATE POLICY "Fiscal assigned access" ON denuncias FOR SELECT 
  USING (fiscal_id = auth.uid());

-- Cidadao can insert denuncias
CREATE POLICY "Cidadao insert denuncia" ON denuncias FOR INSERT 
  WITH CHECK (true);

-- Cidadao can view by protocolo
CREATE POLICY "Cidadao view by protocolo" ON denuncias FOR SELECT 
  USING (true);
`;
