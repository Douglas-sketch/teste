import { 
  Denuncia, 
  Profile, 
  Foto, 
  Relatorio, 
  AutoInfracao, 
  MensagemChat, 
  Notificacao,
  HistoricoAtividade,
  SEED_FISCAIS, 
  SEED_GERENTE,
  Prioridade,
  FiscalStatusCampo
} from '@/types/database';

// Local Storage Keys
const STORAGE_KEYS = {
  DENUNCIAS: 'sifu_denuncias',
  PROFILES: 'sifu_profiles',
  FOTOS: 'sifu_fotos',
  RELATORIOS: 'sifu_relatorios',
  AUTOS: 'sifu_autos',
  MENSAGENS: 'sifu_mensagens',
  NOTIFICACOES: 'sifu_notificacoes',
  HISTORICO: 'sifu_historico',
  PROTOCOLO_COUNTER: 'sifu_protocolo_counter',
  CURRENT_USER: 'sifu_current_user',
  THEME: 'sifu_theme'
};

// Event system for real-time updates
type Listener = () => void;
const listeners: Map<string, Set<Listener>> = new Map();

export function subscribe(key: string, listener: Listener) {
  if (!listeners.has(key)) {
    listeners.set(key, new Set());
  }
  listeners.get(key)!.add(listener);
  return () => listeners.get(key)?.delete(listener);
}

function notify(key: string) {
  listeners.get(key)?.forEach(l => l());
  listeners.get('*')?.forEach(l => l());
}

// Helpers
function getFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function setToStorage<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
  notify(key);
}

// Initialize seed data
function initializeSeedData() {
  const profiles = getFromStorage<Profile[]>(STORAGE_KEYS.PROFILES, []);
  if (profiles.length === 0) {
    const seedProfiles: Profile[] = [
      ...SEED_FISCAIS.map(p => ({ ...p, created_at: new Date().toISOString() })),
      { ...SEED_GERENTE, created_at: new Date().toISOString() }
    ];
    setToStorage(STORAGE_KEYS.PROFILES, seedProfiles);
  }
}

initializeSeedData();

// Generate protocol number
export function generateProtocolo(): string {
  const year = new Date().getFullYear();
  const counter = getFromStorage(STORAGE_KEYS.PROTOCOLO_COUNTER, 0) + 1;
  setToStorage(STORAGE_KEYS.PROTOCOLO_COUNTER, counter);
  return `${year}-${String(counter).padStart(5, '0')}`;
}

// PROFILES
export function getProfiles(): Profile[] {
  return getFromStorage<Profile[]>(STORAGE_KEYS.PROFILES, []);
}

export function getProfileById(id: string): Profile | undefined {
  return getProfiles().find(p => p.id === id);
}

export function getProfileByMatricula(matricula: string): Profile | undefined {
  return getProfiles().find(p => p.matricula === matricula);
}

export function getProfileByLogin(login: string): Profile | undefined {
  return getProfiles().find(p => p.login_usuario === login);
}

export function getFiscais(): Profile[] {
  return getProfiles().filter(p => p.tipo === 'fiscal');
}

export function updateProfile(id: string, data: Partial<Profile>) {
  const profiles = getProfiles();
  const index = profiles.findIndex(p => p.id === id);
  if (index !== -1) {
    profiles[index] = { ...profiles[index], ...data };
    setToStorage(STORAGE_KEYS.PROFILES, profiles);
  }
}

// CURRENT USER
export function setCurrentUser(profile: Profile | null) {
  if (profile) {
    localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(profile));
  } else {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  }
  notify(STORAGE_KEYS.CURRENT_USER);
}

export function getCurrentUser(): Profile | null {
  try {
    const item = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return item ? JSON.parse(item) : null;
  } catch {
    return null;
  }
}

// DENUNCIAS
export function getDenuncias(): Denuncia[] {
  return getFromStorage<Denuncia[]>(STORAGE_KEYS.DENUNCIAS, []);
}

export function getDenunciaById(id: string): Denuncia | undefined {
  const denuncia = getDenuncias().find(d => d.id === id);
  if (denuncia) {
    if (denuncia.fiscal_id) {
      denuncia.fiscal = getProfileById(denuncia.fiscal_id);
    }
    if (denuncia.gerente_id) {
      denuncia.gerente = getProfileById(denuncia.gerente_id);
    }
  }
  return denuncia;
}

export function getDenunciaByProtocolo(protocolo: string): Denuncia | undefined {
  const denuncia = getDenuncias().find(d => d.protocolo === protocolo);
  if (denuncia) {
    if (denuncia.fiscal_id) {
      denuncia.fiscal = getProfileById(denuncia.fiscal_id);
    }
    if (denuncia.gerente_id) {
      denuncia.gerente = getProfileById(denuncia.gerente_id);
    }
  }
  return denuncia;
}

export function getDenunciasPendentes(): Denuncia[] {
  return getDenuncias()
    .filter(d => d.status === 'pendente')
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
}

export function getDenunciasAguardandoAprovacao(): Denuncia[] {
  return getDenuncias()
    .filter(d => d.status === 'aguardando_aprovacao')
    .map(d => ({
      ...d,
      fiscal: d.fiscal_id ? getProfileById(d.fiscal_id) : undefined
    }));
}

export function getDenunciasByFiscal(fiscalId: string): Denuncia[] {
  return getDenuncias()
    .filter(d => d.fiscal_id === fiscalId)
    .map(d => ({
      ...d,
      gerente: d.gerente_id ? getProfileById(d.gerente_id) : undefined
    }))
    .sort((a, b) => {
      // Sort by SLA deadline (most urgent first)
      if (a.prazo_sla_vence_em && b.prazo_sla_vence_em) {
        return new Date(a.prazo_sla_vence_em).getTime() - new Date(b.prazo_sla_vence_em).getTime();
      }
      return 0;
    });
}

export function createDenuncia(data: Omit<Denuncia, 'id' | 'created_at' | 'updated_at'>): Denuncia {
  const denuncias = getDenuncias();
  const newDenuncia: Denuncia = {
    ...data,
    id: crypto.randomUUID(),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  };
  denuncias.push(newDenuncia);
  setToStorage(STORAGE_KEYS.DENUNCIAS, denuncias);
  
  // Create notification for gerente
  createNotificacao({
    destinatario_id: SEED_GERENTE.id,
    tipo: 'nova_denuncia',
    titulo: 'Nova denúncia recebida',
    mensagem: `Protocolo ${data.protocolo} — ${data.tipo} — ${data.endereco}`,
    denuncia_id: newDenuncia.id
  });
  
  return newDenuncia;
}

export function updateDenuncia(id: string, data: Partial<Denuncia>) {
  const denuncias = getDenuncias();
  const index = denuncias.findIndex(d => d.id === id);
  if (index !== -1) {
    denuncias[index] = { 
      ...denuncias[index], 
      ...data,
      updated_at: new Date().toISOString()
    };
    setToStorage(STORAGE_KEYS.DENUNCIAS, denuncias);
  }
}

export function designarFiscal(
  denunciaId: string, 
  fiscalId: string, 
  gerenteId: string, 
  prioridade: Prioridade
) {
  const prazoSlaHoras = prioridade === 'urgente' ? 24 : prioridade === 'alta' ? 72 : 168;
  const prazoVenceEm = new Date(Date.now() + prazoSlaHoras * 60 * 60 * 1000).toISOString();
  
  const denuncia = getDenunciaById(denunciaId);
  const fiscal = getProfileById(fiscalId);
  
  updateDenuncia(denunciaId, {
    status: 'designada',
    prioridade,
    prazo_sla_horas: prazoSlaHoras,
    prazo_sla_vence_em: prazoVenceEm,
    fiscal_id: fiscalId,
    gerente_id: gerenteId,
    designada_at: new Date().toISOString()
  });
  
  // Notify fiscal
  createNotificacao({
    destinatario_id: fiscalId,
    tipo: 'fiscal_designado',
    titulo: `${prioridade.toUpperCase()}! Nova denúncia designada`,
    mensagem: `${denuncia?.tipo} — ${denuncia?.endereco}`,
    denuncia_id: denunciaId
  });
  
  // Notify cidadao
  if (denuncia) {
    createNotificacao({
      destinatario_protocolo: denuncia.protocolo,
      tipo: 'fiscal_designado',
      titulo: 'Fiscal designado',
      mensagem: `O fiscal ${fiscal?.nome} foi designado para sua denúncia`,
      denuncia_id: denunciaId
    });
  }
}

export function iniciarVistoria(denunciaId: string, fiscalLat: number, fiscalLng: number) {
  const denuncia = getDenunciaById(denunciaId);
  if (!denuncia) return;
  
  let distancia = 0;
  let statusCampo: FiscalStatusCampo = 'a_caminho';
  
  if (denuncia.latitude && denuncia.longitude) {
    distancia = calcularDistancia(fiscalLat, fiscalLng, denuncia.latitude, denuncia.longitude);
    statusCampo = distancia < 100 ? 'no_local' : 'a_caminho';
  }
  
  updateDenuncia(denunciaId, {
    status: 'em_vistoria',
    vistoria_iniciada_at: new Date().toISOString(),
    fiscal_latitude_checkin: fiscalLat,
    fiscal_longitude_checkin: fiscalLng,
    fiscal_distancia_metros: Math.round(distancia),
    fiscal_status_campo: statusCampo
  });
  
  // Notify cidadao
  createNotificacao({
    destinatario_protocolo: denuncia.protocolo,
    tipo: statusCampo === 'no_local' ? 'fiscal_no_local' : 'fiscal_a_caminho',
    titulo: statusCampo === 'no_local' ? 'Fiscal no local' : 'Fiscal a caminho',
    mensagem: statusCampo === 'no_local' 
      ? 'O fiscal chegou ao local da denúncia'
      : `O fiscal está a caminho (~${Math.round(distancia)}m)`,
    denuncia_id: denunciaId
  });
}

// FOTOS
export function getFotos(): Foto[] {
  return getFromStorage<Foto[]>(STORAGE_KEYS.FOTOS, []);
}

export function getFotosByDenuncia(denunciaId: string, tipo?: string): Foto[] {
  return getFotos()
    .filter(f => f.denuncia_id === denunciaId && (!tipo || f.tipo === tipo))
    .sort((a, b) => a.ordem - b.ordem);
}

export function createFoto(data: Omit<Foto, 'id' | 'created_at'>): Foto {
  const fotos = getFotos();
  const newFoto: Foto = {
    ...data,
    id: crypto.randomUUID(),
    created_at: new Date().toISOString()
  };
  fotos.push(newFoto);
  setToStorage(STORAGE_KEYS.FOTOS, fotos);
  return newFoto;
}

// RELATORIOS
export function getRelatorios(): Relatorio[] {
  return getFromStorage<Relatorio[]>(STORAGE_KEYS.RELATORIOS, []);
}

export function getRelatoriosByDenuncia(denunciaId: string): Relatorio[] {
  return getRelatorios()
    .filter(r => r.denuncia_id === denunciaId)
    .map(r => ({
      ...r,
      fiscal: getProfileById(r.fiscal_id)
    }));
}

export function getRelatoriosPendentes(): Relatorio[] {
  return getRelatorios()
    .filter(r => r.status_aprovacao === 'pendente')
    .map(r => ({
      ...r,
      fiscal: getProfileById(r.fiscal_id),
      denuncia: getDenunciaById(r.denuncia_id)
    }));
}

export function createRelatorio(data: Omit<Relatorio, 'id' | 'created_at'>): Relatorio {
  const relatorios = getRelatorios();
  const denuncia = getDenunciaById(data.denuncia_id);
  
  const newRelatorio: Relatorio = {
    ...data,
    id: crypto.randomUUID(),
    created_at: new Date().toISOString()
  };
  relatorios.push(newRelatorio);
  setToStorage(STORAGE_KEYS.RELATORIOS, relatorios);
  
  // Update denuncia status
  updateDenuncia(data.denuncia_id, { status: 'aguardando_aprovacao' });
  
  // Notify gerente
  createNotificacao({
    destinatario_id: SEED_GERENTE.id,
    tipo: 'relatorio_pendente',
    titulo: 'Novo relatório aguardando aprovação',
    mensagem: `Protocolo ${denuncia?.protocolo} — ${data.tipo_relatorio}`,
    denuncia_id: data.denuncia_id
  });
  
  // Add to historico
  createHistoricoAtividade({
    fiscal_id: data.fiscal_id,
    denuncia_id: data.denuncia_id,
    tipo_atividade: 'relatorio',
    descricao: `Relatório: ${data.tipo_relatorio}`,
    local_descricao: denuncia?.endereco,
    valor_ganho: 50
  });
  
  return newRelatorio;
}

export function updateRelatorio(id: string, data: Partial<Relatorio>) {
  const relatorios = getRelatorios();
  const index = relatorios.findIndex(r => r.id === id);
  if (index !== -1) {
    relatorios[index] = { ...relatorios[index], ...data };
    setToStorage(STORAGE_KEYS.RELATORIOS, relatorios);
  }
}

export function aprovarRelatorio(id: string, parecer: string) {
  const relatorio = getRelatorios().find(r => r.id === id);
  if (!relatorio) return;
  
  updateRelatorio(id, {
    status_aprovacao: 'aprovado',
    gerente_parecer: parecer,
    aprovado_at: new Date().toISOString()
  });
  
  const denuncia = getDenunciaById(relatorio.denuncia_id);
  
  // Update denuncia
  updateDenuncia(relatorio.denuncia_id, {
    status: 'concluida',
    concluida_at: new Date().toISOString()
  });
  
  // Notify fiscal
  createNotificacao({
    destinatario_id: relatorio.fiscal_id,
    tipo: 'aprovado',
    titulo: 'Relatório aprovado',
    mensagem: `Protocolo ${denuncia?.protocolo}`,
    denuncia_id: relatorio.denuncia_id
  });
  
  // Notify cidadao
  if (denuncia) {
    createNotificacao({
      destinatario_protocolo: denuncia.protocolo,
      tipo: 'concluida',
      titulo: 'Denúncia concluída',
      mensagem: 'Sua denúncia foi concluída. Acesse para ver o resultado.',
      denuncia_id: relatorio.denuncia_id
    });
  }
}

export function devolverRelatorio(id: string, parecer: string) {
  const relatorio = getRelatorios().find(r => r.id === id);
  if (!relatorio) return;
  
  updateRelatorio(id, {
    status_aprovacao: 'devolvido',
    gerente_parecer: parecer
  });
  
  const denuncia = getDenunciaById(relatorio.denuncia_id);
  
  // Update denuncia back to designada
  updateDenuncia(relatorio.denuncia_id, { status: 'designada' });
  
  // Notify fiscal
  createNotificacao({
    destinatario_id: relatorio.fiscal_id,
    tipo: 'devolvido',
    titulo: 'Relatório devolvido',
    mensagem: `Ver parecer do gerente — ${denuncia?.protocolo}`,
    denuncia_id: relatorio.denuncia_id
  });
}

// AUTOS DE INFRACAO
export function getAutos(): AutoInfracao[] {
  return getFromStorage<AutoInfracao[]>(STORAGE_KEYS.AUTOS, []);
}

export function getAutosByDenuncia(denunciaId: string): AutoInfracao[] {
  return getAutos()
    .filter(a => a.denuncia_id === denunciaId)
    .map(a => ({
      ...a,
      fiscal: getProfileById(a.fiscal_id)
    }));
}

export function getAutosPendentes(): AutoInfracao[] {
  return getAutos()
    .filter(a => a.status_aprovacao === 'pendente')
    .map(a => ({
      ...a,
      fiscal: getProfileById(a.fiscal_id),
      denuncia: getDenunciaById(a.denuncia_id)
    }));
}

export function createAuto(data: Omit<AutoInfracao, 'id' | 'created_at'>): AutoInfracao {
  const autos = getAutos();
  const denuncia = getDenunciaById(data.denuncia_id);
  
  const newAuto: AutoInfracao = {
    ...data,
    id: crypto.randomUUID(),
    created_at: new Date().toISOString()
  };
  autos.push(newAuto);
  setToStorage(STORAGE_KEYS.AUTOS, autos);
  
  // Update denuncia status
  updateDenuncia(data.denuncia_id, { status: 'aguardando_aprovacao' });
  
  // Notify gerente
  createNotificacao({
    destinatario_id: SEED_GERENTE.id,
    tipo: 'auto_pendente',
    titulo: `Auto R$ ${data.valor_total.toLocaleString('pt-BR')} aguardando aprovação`,
    mensagem: `Protocolo ${denuncia?.protocolo}`,
    denuncia_id: data.denuncia_id
  });
  
  // Add to historico
  createHistoricoAtividade({
    fiscal_id: data.fiscal_id,
    denuncia_id: data.denuncia_id,
    tipo_atividade: 'auto_infracao',
    descricao: `Auto de Infração: ${data.infracao_tipo}`,
    local_descricao: denuncia?.endereco,
    valor_ganho: data.valor_total * 0.05 // 5% commission
  });
  
  return newAuto;
}

export function updateAuto(id: string, data: Partial<AutoInfracao>) {
  const autos = getAutos();
  const index = autos.findIndex(a => a.id === id);
  if (index !== -1) {
    autos[index] = { ...autos[index], ...data };
    setToStorage(STORAGE_KEYS.AUTOS, autos);
  }
}

export function aprovarAuto(id: string, parecer: string) {
  const auto = getAutos().find(a => a.id === id);
  if (!auto) return;
  
  updateAuto(id, {
    status: 'aprovado',
    status_aprovacao: 'aprovado',
    gerente_parecer: parecer,
    aprovado_at: new Date().toISOString()
  });
  
  const denuncia = getDenunciaById(auto.denuncia_id);
  
  // Update denuncia
  updateDenuncia(auto.denuncia_id, {
    status: 'concluida',
    concluida_at: new Date().toISOString()
  });
  
  // Notify fiscal
  createNotificacao({
    destinatario_id: auto.fiscal_id,
    tipo: 'aprovado',
    titulo: 'Auto de infração aprovado',
    mensagem: `R$ ${auto.valor_total.toLocaleString('pt-BR')} — ${denuncia?.protocolo}`,
    denuncia_id: auto.denuncia_id
  });
}

// MENSAGENS CHAT
export function getMensagens(): MensagemChat[] {
  return getFromStorage<MensagemChat[]>(STORAGE_KEYS.MENSAGENS, []);
}

export function getMensagensByDenuncia(denunciaId: string): MensagemChat[] {
  return getMensagens()
    .filter(m => m.denuncia_id === denunciaId)
    .map(m => ({
      ...m,
      remetente: getProfileById(m.remetente_id)
    }))
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
}

export function createMensagem(data: Omit<MensagemChat, 'id' | 'created_at' | 'lida'>): MensagemChat {
  const mensagens = getMensagens();
  const denuncia = getDenunciaById(data.denuncia_id);
  const remetente = getProfileById(data.remetente_id);
  
  const newMensagem: MensagemChat = {
    ...data,
    id: crypto.randomUUID(),
    lida: false,
    created_at: new Date().toISOString()
  };
  mensagens.push(newMensagem);
  setToStorage(STORAGE_KEYS.MENSAGENS, mensagens);
  
  // Notify the other party
  const destinatarioId = data.remetente_tipo === 'fiscal' 
    ? denuncia?.gerente_id 
    : denuncia?.fiscal_id;
    
  if (destinatarioId) {
    createNotificacao({
      destinatario_id: destinatarioId,
      tipo: 'mensagem_chat',
      titulo: `💬 ${remetente?.nome}`,
      mensagem: data.texto.substring(0, 50) + (data.texto.length > 50 ? '...' : ''),
      denuncia_id: data.denuncia_id
    });
  }
  
  return newMensagem;
}

// NOTIFICACOES
export function getNotificacoes(): Notificacao[] {
  return getFromStorage<Notificacao[]>(STORAGE_KEYS.NOTIFICACOES, []);
}

export function getNotificacoesByUser(userId: string): Notificacao[] {
  return getNotificacoes()
    .filter(n => n.destinatario_id === userId)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

export function getNotificacoesByProtocolo(protocolo: string): Notificacao[] {
  return getNotificacoes()
    .filter(n => n.destinatario_protocolo === protocolo)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

export function getUnreadCount(userId: string): number {
  return getNotificacoes().filter(n => n.destinatario_id === userId && !n.lida).length;
}

export function createNotificacao(data: Omit<Notificacao, 'id' | 'created_at' | 'lida'>) {
  const notificacoes = getNotificacoes();
  const newNotificacao: Notificacao = {
    ...data,
    id: crypto.randomUUID(),
    lida: false,
    created_at: new Date().toISOString()
  };
  notificacoes.push(newNotificacao);
  setToStorage(STORAGE_KEYS.NOTIFICACOES, notificacoes);
}

export function markNotificacaoAsRead(id: string) {
  const notificacoes = getNotificacoes();
  const index = notificacoes.findIndex(n => n.id === id);
  if (index !== -1) {
    notificacoes[index].lida = true;
    setToStorage(STORAGE_KEYS.NOTIFICACOES, notificacoes);
  }
}

export function markAllAsRead(userId: string) {
  const notificacoes = getNotificacoes();
  notificacoes.forEach(n => {
    if (n.destinatario_id === userId) {
      n.lida = true;
    }
  });
  setToStorage(STORAGE_KEYS.NOTIFICACOES, notificacoes);
}

// HISTORICO ATIVIDADES
export function getHistoricoAtividades(): HistoricoAtividade[] {
  return getFromStorage<HistoricoAtividade[]>(STORAGE_KEYS.HISTORICO, []);
}

export function getHistoricoByFiscal(fiscalId: string, mes?: number, ano?: number): HistoricoAtividade[] {
  return getHistoricoAtividades()
    .filter(h => 
      h.fiscal_id === fiscalId && 
      (!mes || h.mes === mes) && 
      (!ano || h.ano === ano)
    )
    .map(h => ({
      ...h,
      denuncia: getDenunciaById(h.denuncia_id)
    }))
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

export function createHistoricoAtividade(data: Omit<HistoricoAtividade, 'id' | 'created_at' | 'mes' | 'ano'>) {
  const historico = getHistoricoAtividades();
  const now = new Date();
  const newHistorico: HistoricoAtividade = {
    ...data,
    id: crypto.randomUUID(),
    mes: now.getMonth() + 1,
    ano: now.getFullYear(),
    created_at: now.toISOString()
  };
  historico.push(newHistorico);
  setToStorage(STORAGE_KEYS.HISTORICO, historico);
}

// PRODUTIVIDADE
export function getProdutividade(fiscalId: string, mes: number, ano: number) {
  const historico = getHistoricoByFiscal(fiscalId, mes, ano);
  return {
    vistorias: historico.filter(h => h.tipo_atividade === 'vistoria').length,
    autos: historico.filter(h => h.tipo_atividade === 'auto_infracao').length,
    relatorios: historico.filter(h => h.tipo_atividade === 'relatorio').length,
    total_ganho: historico.reduce((sum, h) => sum + h.valor_ganho, 0),
    total_atividades: historico.length
  };
}

// DASHBOARD
export function getDashboardStats() {
  const denuncias = getDenuncias();
  return {
    pendentes: denuncias.filter(d => d.status === 'pendente').length,
    em_andamento: denuncias.filter(d => ['designada', 'em_vistoria'].includes(d.status)).length,
    concluidas: denuncias.filter(d => d.status === 'concluida').length,
    aguardando_aprovacao: denuncias.filter(d => d.status === 'aguardando_aprovacao').length
  };
}

// HISTORICO ENDERECO
export function getHistoricoEndereco(endereco: string) {
  const denuncias = getDenuncias().filter(d => 
    d.endereco.toLowerCase().includes(endereco.toLowerCase()) ||
    endereco.toLowerCase().includes(d.endereco.toLowerCase())
  );
  
  return {
    endereco,
    total_ocorrencias: denuncias.length,
    protocolos: denuncias.map(d => d.protocolo),
    tipos: denuncias.map(d => d.tipo),
    statuses: denuncias.map(d => d.status),
    datas: denuncias.map(d => d.created_at)
  };
}

// UTILS
function calcularDistancia(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) *
    Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

// THEME
export function getTheme(): 'dark' | 'light' {
  return getFromStorage(STORAGE_KEYS.THEME, 'dark') as 'dark' | 'light';
}

export function setTheme(theme: 'dark' | 'light') {
  setToStorage(STORAGE_KEYS.THEME, theme);
  if (theme === 'light') {
    document.documentElement.classList.add('light-theme');
  } else {
    document.documentElement.classList.remove('light-theme');
  }
}

// Initialize theme
const savedTheme = getTheme();
if (savedTheme === 'light') {
  document.documentElement.classList.add('light-theme');
}
