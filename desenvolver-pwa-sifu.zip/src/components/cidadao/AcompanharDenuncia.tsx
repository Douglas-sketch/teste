import { useState, useEffect } from 'react';
import { ArrowLeft, Search, QrCode, Clock, MapPin, User, AlertTriangle, Check, FileText, Camera } from 'lucide-react';
import { Denuncia, Foto } from '@/types/database';
import { getDenunciaByProtocolo, getFotosByDenuncia, getHistoricoEndereco, subscribe } from '@/lib/store';

interface AcompanharDenunciaProps {
  onBack: () => void;
}

export function AcompanharDenuncia({ onBack }: AcompanharDenunciaProps) {
  const [protocolo, setProtocolo] = useState('');
  const [denuncia, setDenuncia] = useState<Denuncia | null>(null);
  const [fotos, setFotos] = useState<Foto[]>([]);
  const [searching, setSearching] = useState(false);
  const [notFound, setNotFound] = useState(false);
  const [showScanner, setShowScanner] = useState(false);

  // Subscribe to realtime updates
  useEffect(() => {
    if (!denuncia) return;
    
    const unsubscribe = subscribe('sifu_denuncias', () => {
      const updated = getDenunciaByProtocolo(denuncia.protocolo);
      if (updated) setDenuncia(updated);
    });
    
    return () => { unsubscribe(); };
  }, [denuncia?.protocolo]);

  const handleSearch = () => {
    if (!protocolo.trim()) return;
    
    setSearching(true);
    setNotFound(false);
    
    // Simulate search delay
    setTimeout(() => {
      const found = getDenunciaByProtocolo(protocolo.trim().toUpperCase());
      if (found) {
        setDenuncia(found);
        setFotos(getFotosByDenuncia(found.id, 'denuncia'));
      } else {
        setNotFound(true);
      }
      setSearching(false);
    }, 500);
  };

  // Format protocol input
  const formatProtocolo = (value: string) => {
    const clean = value.replace(/[^0-9]/g, '');
    if (clean.length <= 4) return clean;
    return `${clean.slice(0, 4)}-${clean.slice(4, 9)}`;
  };

  // Calculate SLA status
  const getSlaStatus = (denuncia: Denuncia) => {
    if (!denuncia.prazo_sla_vence_em) return null;
    
    const now = new Date();
    const deadline = new Date(denuncia.prazo_sla_vence_em);
    const designada = new Date(denuncia.designada_at || denuncia.created_at);
    const total = deadline.getTime() - designada.getTime();
    const remaining = deadline.getTime() - now.getTime();
    const percentage = Math.max(0, Math.min(100, (remaining / total) * 100));
    
    const hoursRemaining = Math.floor(remaining / (1000 * 60 * 60));
    const isVencido = remaining < 0;
    
    let color = 'sla-green';
    if (percentage < 20) color = 'sla-red';
    else if (percentage < 50) color = 'sla-yellow';
    
    return { percentage, hoursRemaining, isVencido, color };
  };

  // Get status badge
  const getStatusBadge = (status: string) => {
    const badges: Record<string, { label: string; class: string }> = {
      pendente: { label: 'Pendente', class: 'badge-pendente' },
      designada: { label: 'Designada', class: 'badge-designada' },
      em_vistoria: { label: 'Em Vistoria', class: 'badge-em-vistoria' },
      aguardando_aprovacao: { label: 'Em Análise', class: 'badge-aguardando' },
      concluida: { label: 'Concluída', class: 'badge-concluida' }
    };
    return badges[status] || { label: status, class: '' };
  };

  // Get historico
  const historico = denuncia ? getHistoricoEndereco(denuncia.endereco) : null;

  // Render search view
  if (!denuncia) {
    return (
      <div className="min-h-screen bg-[var(--bg-primary)]">
        {/* Header */}
        <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="text-[var(--text-secondary)]">
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-lg font-semibold text-[var(--text-primary)]">Acompanhar Denúncia</h1>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4">
          {/* Search */}
          <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
            <label className="text-sm text-[var(--text-secondary)] mb-2 block">
              Digite o número do protocolo
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="2026-00001"
                value={protocolo}
                onChange={e => setProtocolo(formatProtocolo(e.target.value))}
                className="flex-1 px-4 py-3 rounded-xl font-mono text-lg"
                maxLength={10}
              />
              <button
                onClick={handleSearch}
                disabled={!protocolo.trim() || searching}
                className="px-4 rounded-xl bg-[#00D4AA] text-white disabled:opacity-50"
              >
                <Search size={20} />
              </button>
            </div>
          </div>

          {/* QR Scanner */}
          <button
            onClick={() => setShowScanner(true)}
            className="w-full p-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border)] flex items-center gap-3 text-[var(--text-primary)]"
          >
            <div className="w-10 h-10 rounded-lg bg-[#3B82F6]/20 flex items-center justify-center">
              <QrCode className="text-[#3B82F6]" size={20} />
            </div>
            <div className="text-left">
              <p className="font-medium">Escanear QR Code</p>
              <p className="text-sm text-[var(--text-secondary)]">Use a câmera para ler o código</p>
            </div>
          </button>

          {/* Not found */}
          {notFound && (
            <div className="bg-[#FF4757]/10 border border-[#FF4757]/30 rounded-2xl p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-[#FF4757]/20 flex items-center justify-center mx-auto mb-3">
                <AlertTriangle className="text-[#FF4757]" size={24} />
              </div>
              <p className="text-[var(--text-primary)] font-medium">Protocolo não encontrado</p>
              <p className="text-sm text-[var(--text-secondary)] mt-1">
                Verifique o número e tente novamente
              </p>
            </div>
          )}

          {/* QR Scanner Modal */}
          {showScanner && (
            <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
              <div className="bg-[var(--bg-card)] rounded-2xl p-6 max-w-sm w-full text-center">
                <QrCode size={48} className="mx-auto mb-4 text-[var(--text-muted)]" />
                <p className="text-[var(--text-primary)] mb-2">Scanner de QR Code</p>
                <p className="text-sm text-[var(--text-secondary)] mb-4">
                  Funcionalidade disponível em dispositivos com câmera
                </p>
                <button
                  onClick={() => setShowScanner(false)}
                  className="w-full py-3 rounded-xl bg-[var(--bg-card-secondary)] text-[var(--text-primary)]"
                >
                  Fechar
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Render denuncia details
  const sla = getSlaStatus(denuncia);
  const badge = getStatusBadge(denuncia.status);

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center gap-3">
          <button onClick={() => setDenuncia(null)} className="text-[var(--text-secondary)]">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-lg font-semibold text-[var(--text-primary)]">Protocolo {denuncia.protocolo}</h1>
            <span className={`badge ${badge.class}`}>{badge.label}</span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4 pb-24">
        {/* Status Card */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-[var(--text-secondary)]">Status atual</span>
            <span className={`badge ${badge.class}`}>{badge.label}</span>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex items-start gap-2">
              <FileText size={16} className="text-[var(--text-muted)] mt-0.5" />
              <div>
                <span className="text-[var(--text-secondary)]">Tipo: </span>
                <span className="text-[var(--text-primary)]">{denuncia.tipo}</span>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <MapPin size={16} className="text-[var(--text-muted)] mt-0.5" />
              <div>
                <span className="text-[var(--text-secondary)]">Local: </span>
                <span className="text-[var(--text-primary)]">{denuncia.endereco}</span>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <Clock size={16} className="text-[var(--text-muted)] mt-0.5" />
              <div>
                <span className="text-[var(--text-secondary)]">Data: </span>
                <span className="text-[var(--text-primary)]">
                  {new Date(denuncia.created_at).toLocaleDateString('pt-BR')} às {new Date(denuncia.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <User size={16} className="text-[var(--text-muted)] mt-0.5" />
              <div>
                <span className="text-[var(--text-secondary)]">Denunciante: </span>
                <span className="text-[var(--text-primary)]">{denuncia.denunciante_nome}</span>
              </div>
            </div>
          </div>
        </div>

        {/* SLA */}
        {sla && denuncia.status !== 'concluida' && (
          <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-[var(--text-secondary)]">Prazo para conclusão</span>
              {sla.isVencido ? (
                <span className="text-[#FF4757] text-sm font-medium">⚠️ Vencido há {Math.abs(sla.hoursRemaining)}h</span>
              ) : (
                <span className="text-[var(--text-primary)] text-sm font-medium">
                  {sla.hoursRemaining > 24 ? `${Math.floor(sla.hoursRemaining / 24)} dias` : `${sla.hoursRemaining}h`} restantes
                </span>
              )}
            </div>
            <div className="progress-bar">
              <div className={`progress-bar-fill ${sla.color}`} style={{ width: `${sla.percentage}%` }} />
            </div>
          </div>
        )}

        {/* Fiscal Info */}
        {denuncia.fiscal && (
          <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
            <h3 className="text-sm text-[var(--text-secondary)] mb-3">Fiscal Responsável</h3>
            <div className="flex items-center gap-3">
              <div 
                className="w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold"
                style={{ backgroundColor: denuncia.fiscal.avatar_color }}
              >
                {denuncia.fiscal.avatar_initials}
              </div>
              <div>
                <p className="font-medium text-[var(--text-primary)]">{denuncia.fiscal.nome}</p>
                <p className="text-sm text-[var(--text-secondary)]">Matrícula: {denuncia.fiscal.matricula}</p>
              </div>
            </div>
            
            {/* Fiscal a caminho */}
            {denuncia.fiscal_status_campo && denuncia.status === 'em_vistoria' && (
              <div className={`mt-3 px-3 py-2 rounded-lg flex items-center gap-2 ${
                denuncia.fiscal_status_campo === 'no_local' 
                  ? 'bg-[#00D4AA]/20 text-[#00D4AA]' 
                  : 'bg-[#FFB020]/20 text-[#FFB020]'
              }`}>
                <span className="w-2 h-2 rounded-full bg-current animate-pulse" />
                {denuncia.fiscal_status_campo === 'no_local' 
                  ? '🟢 Fiscal no local'
                  : `🟢 Fiscal a caminho — ~${denuncia.fiscal_distancia_metros}m`
                }
              </div>
            )}
          </div>
        )}

        {/* Timeline */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
          <h3 className="text-sm text-[var(--text-secondary)] mb-4">Linha do tempo</h3>
          <div className="space-y-0">
            {/* Recebida */}
            <div className="timeline-item pb-4">
              <div className="timeline-dot bg-[#00D4AA]">
                <Check size={10} className="text-white" />
              </div>
              <div>
                <p className="font-medium text-[var(--text-primary)]">Denúncia recebida</p>
                <p className="text-sm text-[var(--text-secondary)]">
                  {new Date(denuncia.created_at).toLocaleDateString('pt-BR')} às {new Date(denuncia.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>

            {/* Designada */}
            <div className="timeline-item pb-4">
              <div className={`timeline-dot ${denuncia.designada_at ? 'bg-[#00D4AA]' : 'bg-[var(--bg-card-secondary)]'}`}>
                {denuncia.designada_at ? <Check size={10} className="text-white" /> : null}
              </div>
              <div>
                <p className={`font-medium ${denuncia.designada_at ? 'text-[var(--text-primary)]' : 'text-[var(--text-muted)]'}`}>
                  Fiscal designado
                </p>
                {denuncia.designada_at && denuncia.fiscal && (
                  <p className="text-sm text-[var(--text-secondary)]">
                    {denuncia.fiscal.nome} — {new Date(denuncia.designada_at).toLocaleDateString('pt-BR')}
                  </p>
                )}
              </div>
            </div>

            {/* Vistoria */}
            <div className="timeline-item pb-4">
              <div className={`timeline-dot ${
                denuncia.status === 'em_vistoria' 
                  ? 'bg-[#FFB020] animate-pulse' 
                  : denuncia.vistoria_iniciada_at 
                    ? 'bg-[#00D4AA]' 
                    : 'bg-[var(--bg-card-secondary)]'
              }`}>
                {denuncia.vistoria_iniciada_at ? <Check size={10} className="text-white" /> : null}
              </div>
              <div>
                <p className={`font-medium ${denuncia.vistoria_iniciada_at ? 'text-[var(--text-primary)]' : 'text-[var(--text-muted)]'}`}>
                  Vistoria {denuncia.status === 'em_vistoria' ? 'em andamento' : (denuncia.vistoria_iniciada_at ? 'realizada' : 'pendente')}
                </p>
                {denuncia.vistoria_iniciada_at && (
                  <p className="text-sm text-[var(--text-secondary)]">
                    {new Date(denuncia.vistoria_iniciada_at).toLocaleDateString('pt-BR')}
                  </p>
                )}
              </div>
            </div>

            {/* Análise */}
            <div className="timeline-item pb-4">
              <div className={`timeline-dot ${
                denuncia.status === 'aguardando_aprovacao' 
                  ? 'bg-[#8B5CF6]' 
                  : denuncia.concluida_at 
                    ? 'bg-[#00D4AA]' 
                    : 'bg-[var(--bg-card-secondary)]'
              }`}>
                {denuncia.concluida_at ? <Check size={10} className="text-white" /> : null}
              </div>
              <div>
                <p className={`font-medium ${['aguardando_aprovacao', 'concluida'].includes(denuncia.status) ? 'text-[var(--text-primary)]' : 'text-[var(--text-muted)]'}`}>
                  Parecer e providências
                </p>
              </div>
            </div>

            {/* Conclusão */}
            <div className="timeline-item">
              <div className={`timeline-dot ${denuncia.concluida_at ? 'bg-[#00D4AA]' : 'bg-[var(--bg-card-secondary)]'}`}>
                {denuncia.concluida_at ? <Check size={10} className="text-white" /> : null}
              </div>
              <div>
                <p className={`font-medium ${denuncia.concluida_at ? 'text-[var(--text-primary)]' : 'text-[var(--text-muted)]'}`}>
                  Conclusão
                </p>
                {denuncia.concluida_at && (
                  <p className="text-sm text-[var(--text-secondary)]">
                    {new Date(denuncia.concluida_at).toLocaleDateString('pt-BR')}
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Histórico do endereço */}
        {historico && historico.total_ocorrencias > 1 && (
          <div className="bg-[#FFB020]/10 border border-[#FFB020]/30 rounded-2xl p-4">
            <div className="flex items-center gap-2 text-[#FFB020] mb-3">
              <AlertTriangle size={18} />
              <span className="font-medium">Este local teve {historico.total_ocorrencias - 1} ocorrência(s) anterior(es)</span>
            </div>
            <div className="space-y-2">
              {historico.protocolos.slice(0, 3).filter(p => p !== denuncia.protocolo).map((prot, i) => (
                <div key={prot} className="flex items-center justify-between text-sm">
                  <span className="text-[var(--text-secondary)]">{prot}</span>
                  <span className="text-[var(--text-primary)]">{historico.tipos[i]}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {historico && historico.total_ocorrencias === 1 && (
          <div className="bg-[#00D4AA]/10 border border-[#00D4AA]/30 rounded-2xl p-4">
            <div className="flex items-center gap-2 text-[#00D4AA]">
              <Check size={18} />
              <span className="font-medium">Primeira ocorrência neste endereço</span>
            </div>
          </div>
        )}

        {/* Fotos */}
        {fotos.length > 0 && (
          <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
            <div className="flex items-center gap-2 mb-3">
              <Camera size={18} className="text-[var(--text-muted)]" />
              <h3 className="text-sm text-[var(--text-secondary)]">Fotos da denúncia</h3>
            </div>
            <div className="flex gap-2 overflow-x-auto hide-scrollbar">
              {fotos.map(foto => (
                <img 
                  key={foto.id}
                  src={foto.url_marca_dagua || foto.url}
                  alt=""
                  className="w-24 h-24 rounded-lg object-cover flex-shrink-0"
                />
              ))}
            </div>
          </div>
        )}

        {/* Descrição */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
          <h3 className="text-sm text-[var(--text-secondary)] mb-2">Descrição</h3>
          <p className="text-[var(--text-primary)]">{denuncia.descricao}</p>
        </div>
      </div>
    </div>
  );
}
