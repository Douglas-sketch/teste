import { useState, useRef } from 'react';
import { ArrowLeft, MapPin, Camera, Mic, MicOff, Check, X, AlertTriangle } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { TIPOS_DENUNCIA } from '@/types/database';
import { createDenuncia, createFoto, generateProtocolo, getHistoricoEndereco } from '@/lib/store';

interface NovaDenunciaProps {
  onBack: () => void;
}

type Step = 1 | 2 | 3 | 'success';

export function NovaDenuncia({ onBack }: NovaDenunciaProps) {
  const [step, setStep] = useState<Step>(1);
  const [isAnonimo, setIsAnonimo] = useState(true);
  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');
  const [tipoSelecionado, setTipoSelecionado] = useState('');
  const [endereco, setEndereco] = useState('');
  const [referencia, setReferencia] = useState('');
  const [descricao, setDescricao] = useState('');
  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);
  const [precisaoGps, setPrecisaoGps] = useState<number | null>(null);
  const [fotos, setFotos] = useState<string[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [protocolo, setProtocolo] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);

  // Format phone number
  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 2) return numbers;
    if (numbers.length <= 7) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
  };

  // Get GPS location
  const getLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocalização não suportada pelo navegador');
      return;
    }
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLatitude(position.coords.latitude);
        setLongitude(position.coords.longitude);
        setPrecisaoGps(position.coords.accuracy);
        setGpsLoading(false);
      },
      (error) => {
        console.error('GPS Error:', error);
        setGpsLoading(false);
        alert('Não foi possível obter localização');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  // Voice recording
  const toggleRecording = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Reconhecimento de voz não suportado');
      return;
    }

    if (isRecording && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsRecording(false);
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = 'pt-BR';
    recognition.continuous = true;
    recognition.interimResults = true;

    recognition.onresult = (event: any) => {
      let transcript = '';
      for (let i = 0; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      setDescricao(transcript);
    };

    recognition.onerror = () => {
      setIsRecording(false);
    };

    recognition.onend = () => {
      setIsRecording(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
    setIsRecording(true);
  };

  // Handle photo capture/upload
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      if (fotos.length >= 4) return;
      
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          // Add watermark
          addWatermark(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const addWatermark = (imageData: string) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      
      if (ctx) {
        // Draw original image
        ctx.drawImage(img, 0, 0);
        
        // Add watermark
        const now = new Date();
        const dateStr = now.toLocaleDateString('pt-BR');
        const timeStr = now.toLocaleTimeString('pt-BR');
        const gpsStr = latitude && longitude ? `${latitude.toFixed(6)}, ${longitude.toFixed(6)}` : 'GPS não disponível';
        
        ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
        ctx.fillRect(0, canvas.height - 60, canvas.width, 60);
        
        ctx.font = '14px Inter, sans-serif';
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.fillText(`${dateStr} ${timeStr}`, 10, canvas.height - 40);
        ctx.fillText(gpsStr, 10, canvas.height - 20);
        ctx.fillText('SIFU — Pref. Cabo de S.A.', canvas.width - 180, canvas.height - 20);
        
        const watermarkedImage = canvas.toDataURL('image/jpeg', 0.8);
        setFotos(prev => [...prev.slice(0, 3), watermarkedImage]);
      }
    };
    
    img.src = imageData;
  };

  const removePhoto = (index: number) => {
    setFotos(prev => prev.filter((_, i) => i !== index));
  };

  // Validation
  const isStep1Valid = tipoSelecionado !== '';
  const isStep2Valid = endereco.trim() !== '' && descricao.trim() !== '';

  // Submit
  const handleSubmit = async () => {
    setSubmitting(true);
    
    const tipo = TIPOS_DENUNCIA.find(t => t.codigo === tipoSelecionado);
    const newProtocolo = generateProtocolo();
    
    // Create denuncia
    const denuncia = createDenuncia({
      protocolo: newProtocolo,
      denunciante_nome: isAnonimo ? 'Anônimo' : (nome || 'Anônimo'),
      denunciante_telefone: isAnonimo ? null : telefone || null,
      denunciante_anonimo: isAnonimo,
      tipo: tipo?.label || 'Outro',
      tipo_codigo: tipoSelecionado,
      endereco,
      ponto_referencia: referencia || null,
      latitude,
      longitude,
      precisao_gps: precisaoGps,
      descricao,
      status: 'pendente',
      qrcode_data: `https://sifu.app/acompanhar/${newProtocolo}`
    });
    
    // Create photos
    fotos.forEach((fotoUrl, index) => {
      createFoto({
        denuncia_id: denuncia.id,
        tipo: 'denuncia',
        url: fotoUrl,
        url_marca_dagua: fotoUrl,
        marca_dagua_dados: {
          data: new Date().toLocaleDateString('pt-BR'),
          hora: new Date().toLocaleTimeString('pt-BR'),
          gps: latitude && longitude ? `${latitude}, ${longitude}` : undefined,
          protocolo: newProtocolo
        },
        ordem: index
      });
    });
    
    setProtocolo(newProtocolo);
    setSubmitting(false);
    setStep('success');
  };

  // Get historico for current address
  const historico = endereco ? getHistoricoEndereco(endereco) : null;

  // Render success screen
  if (step === 'success') {
    return (
      <div className="min-h-screen bg-[var(--bg-primary)] flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
          <div className="w-20 h-20 rounded-full bg-[#00D4AA]/20 flex items-center justify-center mb-6">
            <Check className="w-10 h-10 text-[#00D4AA]" />
          </div>
          
          <h1 className="text-2xl font-bold text-[var(--text-primary)] mb-2">
            Denúncia Registrada!
          </h1>
          <p className="text-[var(--text-secondary)] mb-8">
            Sua denúncia foi recebida com sucesso
          </p>

          {/* Protocolo */}
          <div className="bg-[var(--bg-card)] rounded-2xl p-6 border border-[var(--border)] mb-6 w-full max-w-sm">
            <p className="text-sm text-[var(--text-secondary)] mb-2">Protocolo</p>
            <p className="text-3xl font-bold text-[#00D4AA] font-mono">{protocolo}</p>
          </div>

          {/* QR Code */}
          <div className="bg-white rounded-2xl p-4 mb-6">
            <QRCodeSVG 
              value={`https://sifu.app/acompanhar/${protocolo}`}
              size={180}
              level="H"
              includeMargin
            />
          </div>
          <p className="text-sm text-[var(--text-secondary)] mb-8">
            Escaneie o QR Code para acompanhar
          </p>

          {/* Actions */}
          <div className="w-full max-w-sm space-y-3">
            <button
              onClick={onBack}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-[#00D4AA] to-[#00B894] font-semibold text-white"
            >
              Acompanhar Denúncia
            </button>
            <button
              onClick={onBack}
              className="w-full py-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border)] font-semibold text-[var(--text-primary)]"
            >
              Voltar ao Início
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg-primary)] flex flex-col">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center gap-3 mb-4">
          <button onClick={step === 1 ? onBack : () => setStep((step - 1) as Step)} className="text-[var(--text-secondary)]">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-lg font-semibold text-[var(--text-primary)]">Nova Denúncia</h1>
        </div>
        
        {/* Progress */}
        <div className="flex gap-2">
          {[1, 2, 3].map(s => (
            <div 
              key={s}
              className={`flex-1 h-1 rounded-full ${
                s <= step ? 'bg-[#00D4AA]' : 'bg-[var(--bg-card-secondary)]'
              }`}
            />
          ))}
        </div>
        <div className="flex justify-between mt-2">
          <span className={`text-xs ${step >= 1 ? 'text-[#00D4AA]' : 'text-[var(--text-muted)]'}`}>Identificação</span>
          <span className={`text-xs ${step >= 2 ? 'text-[#00D4AA]' : 'text-[var(--text-muted)]'}`}>Local e Detalhes</span>
          <span className={`text-xs ${step >= 3 ? 'text-[#00D4AA]' : 'text-[var(--text-muted)]'}`}>Fotos</span>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-4">
        {/* STEP 1 */}
        {step === 1 && (
          <div className="space-y-4">
            {/* Anonimo Toggle */}
            <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-[var(--text-primary)]">Denúncia anônima</p>
                  <p className="text-sm text-[var(--text-secondary)]">Seus dados não serão divulgados</p>
                </div>
                <button
                  onClick={() => setIsAnonimo(!isAnonimo)}
                  className={`toggle-switch ${isAnonimo ? 'active' : ''}`}
                />
              </div>
            </div>

            {/* Nome e Telefone */}
            {!isAnonimo && (
              <div className="space-y-3">
                <div>
                  <label className="text-sm text-[var(--text-secondary)] mb-1 block">Nome (opcional)</label>
                  <input
                    type="text"
                    placeholder="Seu nome"
                    value={nome}
                    onChange={e => setNome(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl"
                  />
                </div>
                <div>
                  <label className="text-sm text-[var(--text-secondary)] mb-1 block">Telefone</label>
                  <input
                    type="tel"
                    placeholder="(00) 00000-0000"
                    value={telefone}
                    onChange={e => setTelefone(formatPhone(e.target.value))}
                    className="w-full px-4 py-3 rounded-xl"
                    maxLength={15}
                  />
                </div>
              </div>
            )}

            {/* Tipo de Denúncia */}
            <div>
              <label className="text-sm text-[var(--text-secondary)] mb-2 block">
                Tipo de irregularidade <span className="text-[#FF4757]">*</span>
              </label>
              <div className="space-y-2">
                {TIPOS_DENUNCIA.map(tipo => (
                  <button
                    key={tipo.codigo}
                    onClick={() => setTipoSelecionado(tipo.codigo)}
                    className={`w-full p-4 rounded-xl border text-left flex items-center gap-3 transition-all ${
                      tipoSelecionado === tipo.codigo
                        ? 'bg-[#00D4AA]/10 border-[#00D4AA]'
                        : 'bg-[var(--bg-card)] border-[var(--border)]'
                    }`}
                  >
                    <span className="text-2xl">{tipo.icon}</span>
                    <span className={tipoSelecionado === tipo.codigo ? 'text-[#00D4AA]' : 'text-[var(--text-primary)]'}>
                      {tipo.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 2 */}
        {step === 2 && (
          <div className="space-y-4">
            {/* Endereço */}
            <div>
              <label className="text-sm text-[var(--text-secondary)] mb-1 block">
                Endereço completo <span className="text-[#FF4757]">*</span>
              </label>
              <input
                type="text"
                placeholder="Rua, número, bairro"
                value={endereco}
                onChange={e => setEndereco(e.target.value)}
                className="w-full px-4 py-3 rounded-xl"
              />
            </div>

            {/* Referência */}
            <div>
              <label className="text-sm text-[var(--text-secondary)] mb-1 block">Ponto de referência</label>
              <input
                type="text"
                placeholder="Próximo a..."
                value={referencia}
                onChange={e => setReferencia(e.target.value)}
                className="w-full px-4 py-3 rounded-xl"
              />
            </div>

            {/* GPS */}
            <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <MapPin className="text-[#00D4AA]" size={20} />
                  <span className="font-medium text-[var(--text-primary)]">Localização GPS</span>
                </div>
                <button
                  onClick={getLocation}
                  disabled={gpsLoading}
                  className="px-4 py-2 rounded-lg bg-[#00D4AA]/20 text-[#00D4AA] text-sm font-medium"
                >
                  {gpsLoading ? 'Obtendo...' : latitude ? 'Atualizar' : 'Usar minha localização'}
                </button>
              </div>
              {latitude && longitude && (
                <div className="text-sm text-[var(--text-secondary)] space-y-1">
                  <p>📍 {latitude.toFixed(6)}, {longitude.toFixed(6)}</p>
                  {precisaoGps && <p>Precisão: ±{Math.round(precisaoGps)}m</p>}
                </div>
              )}
            </div>

            {/* Historico do endereço */}
            {historico && historico.total_ocorrencias > 0 && (
              <div className="bg-[#FFB020]/10 border border-[#FFB020]/30 rounded-2xl p-4">
                <div className="flex items-center gap-2 text-[#FFB020] mb-2">
                  <AlertTriangle size={18} />
                  <span className="font-medium">Endereço com histórico</span>
                </div>
                <p className="text-sm text-[var(--text-secondary)]">
                  {historico.total_ocorrencias} ocorrência(s) anterior(es) neste local
                </p>
              </div>
            )}

            {/* Descrição */}
            <div>
              <label className="text-sm text-[var(--text-secondary)] mb-1 block">
                Descrição detalhada <span className="text-[#FF4757]">*</span>
              </label>
              <div className="relative">
                <textarea
                  placeholder="Descreva a irregularidade com o máximo de detalhes..."
                  value={descricao}
                  onChange={e => setDescricao(e.target.value)}
                  rows={5}
                  className="w-full px-4 py-3 rounded-xl resize-none pr-12"
                />
                {/* Mic button */}
                {'webkitSpeechRecognition' in window || 'SpeechRecognition' in window ? (
                  <button
                    onClick={toggleRecording}
                    className={`absolute right-3 bottom-3 w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                      isRecording 
                        ? 'bg-[#FF4757] animate-recording' 
                        : 'bg-[var(--bg-card-secondary)]'
                    }`}
                  >
                    {isRecording ? <MicOff size={20} className="text-white" /> : <Mic size={20} className="text-[var(--text-muted)]" />}
                  </button>
                ) : null}
              </div>
              {isRecording && (
                <p className="text-sm text-[#FF4757] mt-2 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#FF4757] animate-pulse" />
                  Gravando... Fale agora
                </p>
              )}
            </div>
          </div>
        )}

        {/* STEP 3 */}
        {step === 3 && (
          <div className="space-y-4">
            {/* Fotos */}
            <div>
              <label className="text-sm text-[var(--text-secondary)] mb-2 block">
                Fotos (opcional, máx. 4)
              </label>
              <div className="photo-grid">
                {[0, 1, 2, 3].map(index => (
                  <div
                    key={index}
                    className="aspect-square rounded-xl bg-[var(--bg-card)] border border-[var(--border)] overflow-hidden relative"
                  >
                    {fotos[index] ? (
                      <>
                        <img src={fotos[index]} alt="" className="w-full h-full object-cover" />
                        <button
                          onClick={() => removePhoto(index)}
                          className="absolute top-2 right-2 w-6 h-6 rounded-full bg-[#FF4757] flex items-center justify-center"
                        >
                          <X size={14} className="text-white" />
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="w-full h-full flex flex-col items-center justify-center text-[var(--text-muted)]"
                      >
                        <Camera size={24} />
                        <span className="text-xs mt-1">Adicionar</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                multiple
                onChange={handlePhotoChange}
                className="hidden"
              />
              <p className="text-xs text-[var(--text-muted)] mt-2">
                📸 As fotos receberão marca d'água com data, hora e localização
              </p>
            </div>

            {/* Resumo */}
            <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
              <h3 className="font-semibold text-[var(--text-primary)] mb-3">Resumo da denúncia</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">Denunciante</span>
                  <span className="text-[var(--text-primary)]">{isAnonimo ? 'Anônimo' : (nome || 'Anônimo')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">Tipo</span>
                  <span className="text-[var(--text-primary)]">{TIPOS_DENUNCIA.find(t => t.codigo === tipoSelecionado)?.label}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">Endereço</span>
                  <span className="text-[var(--text-primary)] text-right max-w-[60%]">{endereco}</span>
                </div>
                {referencia && (
                  <div className="flex justify-between">
                    <span className="text-[var(--text-secondary)]">Referência</span>
                    <span className="text-[var(--text-primary)]">{referencia}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">GPS</span>
                  <span className="text-[var(--text-primary)]">{latitude ? '✓ Obtido' : '✗ Não informado'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[var(--text-secondary)]">Fotos</span>
                  <span className="text-[var(--text-primary)]">{fotos.length} anexada(s)</span>
                </div>
                <div className="pt-2 border-t border-[var(--border)]">
                  <span className="text-[var(--text-secondary)]">Descrição:</span>
                  <p className="text-[var(--text-primary)] mt-1">{descricao}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="p-4 bg-[var(--bg-card)] border-t border-[var(--border)] safe-bottom">
        {step === 3 ? (
          <button
            onClick={handleSubmit}
            disabled={submitting}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-[#00D4AA] to-[#00B894] font-semibold text-white disabled:opacity-50"
          >
            {submitting ? 'Enviando...' : 'Enviar Denúncia'}
          </button>
        ) : (
          <button
            onClick={() => setStep((step + 1) as Step)}
            disabled={step === 1 ? !isStep1Valid : !isStep2Valid}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-[#00D4AA] to-[#00B894] font-semibold text-white disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Continuar
          </button>
        )}
      </div>
    </div>
  );
}

// Add SpeechRecognition type
declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}
