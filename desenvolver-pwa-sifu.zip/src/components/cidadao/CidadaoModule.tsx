import { useState } from 'react';
import { ArrowLeft, PlusCircle, Search, Shield, Lock, ChevronRight } from 'lucide-react';
import { NovaDenuncia } from './NovaDenuncia';
import { AcompanharDenuncia } from './AcompanharDenuncia';

interface CidadaoModuleProps {
  onBack: () => void;
}

type Screen = 'home' | 'nova-denuncia' | 'acompanhar';

export function CidadaoModule({ onBack }: CidadaoModuleProps) {
  const [screen, setScreen] = useState<Screen>('home');

  if (screen === 'nova-denuncia') {
    return <NovaDenuncia onBack={() => setScreen('home')} />;
  }

  if (screen === 'acompanhar') {
    return <AcompanharDenuncia onBack={() => setScreen('home')} />;
  }

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-[var(--text-secondary)]">
            <ArrowLeft size={24} />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#3B82F6]/20 flex items-center justify-center">
              <Shield size={18} className="text-[#3B82F6]" />
            </div>
            <h1 className="text-lg font-semibold text-[var(--text-primary)]">Área do Cidadão</h1>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Main Actions */}
        <div className="grid grid-cols-2 gap-3">
          {/* Nova Denúncia */}
          <button
            onClick={() => setScreen('nova-denuncia')}
            className="p-5 rounded-2xl bg-gradient-to-br from-[#FF4757]/20 to-[#FF4757]/5 border border-[#FF4757]/30 text-left transition-all active:scale-[0.98]"
          >
            <div className="w-12 h-12 rounded-xl bg-[#FF4757]/20 flex items-center justify-center mb-3">
              <PlusCircle className="w-6 h-6 text-[#FF4757]" />
            </div>
            <h3 className="font-semibold text-[var(--text-primary)]">Nova Denúncia</h3>
            <p className="text-xs text-[var(--text-secondary)] mt-1">Registrar irregularidade</p>
          </button>

          {/* Acompanhar */}
          <button
            onClick={() => setScreen('acompanhar')}
            className="p-5 rounded-2xl bg-gradient-to-br from-[#3B82F6]/20 to-[#3B82F6]/5 border border-[#3B82F6]/30 text-left transition-all active:scale-[0.98]"
          >
            <div className="w-12 h-12 rounded-xl bg-[#3B82F6]/20 flex items-center justify-center mb-3">
              <Search className="w-6 h-6 text-[#3B82F6]" />
            </div>
            <h3 className="font-semibold text-[var(--text-primary)]">Acompanhar</h3>
            <p className="text-xs text-[var(--text-secondary)] mt-1">Consultar protocolo</p>
          </button>
        </div>

        {/* Como Funciona */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-5 border border-[var(--border)]">
          <h3 className="font-semibold text-[var(--text-primary)] mb-4">Como funciona?</h3>
          <div className="space-y-4">
            {[
              { num: 1, title: 'Registre', desc: 'Preencha o formulário com os detalhes da denúncia' },
              { num: 2, title: 'Receba o protocolo', desc: 'Guarde o número para acompanhar o andamento' },
              { num: 3, title: 'Fiscal designado', desc: 'Um fiscal será enviado para vistoriar o local' },
              { num: 4, title: 'Acompanhe', desc: 'Veja em tempo real o status da sua denúncia' }
            ].map(step => (
              <div key={step.num} className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-[#00D4AA]/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-[#00D4AA]">{step.num}</span>
                </div>
                <div>
                  <p className="font-medium text-[var(--text-primary)]">{step.title}</p>
                  <p className="text-sm text-[var(--text-secondary)]">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Privacidade */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-5 border border-[var(--border)]">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#8B5CF6]/20 flex items-center justify-center flex-shrink-0">
              <Lock className="w-5 h-5 text-[#8B5CF6]" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-[var(--text-primary)]">Privacidade garantida</h3>
              <p className="text-sm text-[var(--text-secondary)] mt-1">
                Sua denúncia pode ser anônima. Seus dados são protegidos pela LGPD e usados apenas para fins de fiscalização.
              </p>
            </div>
            <ChevronRight className="text-[var(--text-muted)]" />
          </div>
        </div>
      </div>
    </div>
  );
}
