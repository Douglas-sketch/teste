import { useState } from 'react';
import { Users, Shield, Crown, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { Profile } from '@/types/database';
import { getProfileByMatricula, getProfileByLogin, setCurrentUser, updateProfile } from '@/lib/store';

interface ProfileSelectionProps {
  onSelect: (profile: 'cidadao' | 'fiscal' | 'gerente', user?: Profile) => void;
}

export function ProfileSelection({ onSelect }: ProfileSelectionProps) {
  const [showLogin, setShowLogin] = useState<'fiscal' | 'gerente' | null>(null);
  const [credentials, setCredentials] = useState({ matricula: '', usuario: '', senha: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setError('');
    setLoading(true);

    // Simulate network delay
    await new Promise(r => setTimeout(r, 500));

    if (showLogin === 'fiscal') {
      // Demo: accept any password for existing fiscais
      const fiscal = getProfileByMatricula(credentials.matricula);
      if (fiscal) {
        updateProfile(fiscal.id, { status_online: 'em_campo' });
        setCurrentUser(fiscal);
        onSelect('fiscal', fiscal);
      } else {
        setError('Matrícula não encontrada');
      }
    } else if (showLogin === 'gerente') {
      // Demo: accept any password for existing gerentes
      const gerente = getProfileByLogin(credentials.usuario);
      if (gerente) {
        updateProfile(gerente.id, { status_online: 'escritorio' });
        setCurrentUser(gerente);
        onSelect('gerente', gerente);
      } else {
        setError('Usuário não encontrado');
      }
    }

    setLoading(false);
  };

  if (showLogin) {
    return (
      <div className="min-h-screen bg-[var(--bg-primary)] flex flex-col">
        {/* Header */}
        <div className="p-4">
          <button 
            onClick={() => { setShowLogin(null); setError(''); }}
            className="text-[var(--text-secondary)] flex items-center gap-2 text-sm"
          >
            ← Voltar
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col items-center justify-center px-6">
          <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 ${
            showLogin === 'fiscal' ? 'bg-[#00D4AA]/20' : 'bg-[#8B5CF6]/20'
          }`}>
            {showLogin === 'fiscal' 
              ? <Shield className="w-8 h-8 text-[#00D4AA]" />
              : <Crown className="w-8 h-8 text-[#8B5CF6]" />
            }
          </div>

          <h1 className="text-2xl font-bold text-[var(--text-primary)] mb-2">
            {showLogin === 'fiscal' ? 'Acesso Fiscal' : 'Acesso Gerencial'}
          </h1>
          <p className="text-[var(--text-secondary)] text-sm mb-8 text-center">
            {showLogin === 'fiscal' 
              ? 'Insira sua matrícula e senha'
              : 'Insira seu usuário e senha'
            }
          </p>

          <div className="w-full max-w-sm space-y-4">
            {showLogin === 'fiscal' ? (
              <div>
                <label className="text-[var(--text-secondary)] text-sm mb-1 block">Matrícula</label>
                <input
                  type="text"
                  placeholder="FSC-0000"
                  value={credentials.matricula}
                  onChange={e => setCredentials({ ...credentials, matricula: e.target.value.toUpperCase() })}
                  className="w-full px-4 py-3 rounded-xl text-[var(--text-primary)] placeholder:text-[var(--text-muted)]"
                />
              </div>
            ) : (
              <div>
                <label className="text-[var(--text-secondary)] text-sm mb-1 block">Usuário</label>
                <input
                  type="text"
                  placeholder="usuario.sistema"
                  value={credentials.usuario}
                  onChange={e => setCredentials({ ...credentials, usuario: e.target.value.toLowerCase() })}
                  className="w-full px-4 py-3 rounded-xl text-[var(--text-primary)] placeholder:text-[var(--text-muted)]"
                />
              </div>
            )}

            <div>
              <label className="text-[var(--text-secondary)] text-sm mb-1 block">Senha</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={credentials.senha}
                  onChange={e => setCredentials({ ...credentials, senha: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl text-[var(--text-primary)] placeholder:text-[var(--text-muted)] pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-[#FF4757] text-sm bg-[#FF4757]/10 px-4 py-3 rounded-xl">
                <AlertCircle size={18} />
                {error}
              </div>
            )}

            <button
              onClick={handleLogin}
              disabled={loading || (showLogin === 'fiscal' ? !credentials.matricula : !credentials.usuario)}
              className={`w-full py-4 rounded-xl font-semibold text-white transition-all ${
                showLogin === 'fiscal'
                  ? 'bg-gradient-to-r from-[#00D4AA] to-[#00B894]'
                  : 'bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED]'
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              {loading ? 'Entrando...' : 'Entrar'}
            </button>

            {/* Demo hint */}
            <div className="mt-6 p-4 bg-[var(--bg-card)] rounded-xl border border-[var(--border)]">
              <p className="text-xs text-[var(--text-muted)] text-center mb-2">🔑 Demo - Credenciais de teste:</p>
              {showLogin === 'fiscal' ? (
                <div className="text-xs text-[var(--text-secondary)] text-center space-y-1">
                  <p>Matrícula: <span className="text-[#00D4AA] font-mono">FSC-2847</span></p>
                  <p>Matrícula: <span className="text-[#00D4AA] font-mono">FSC-3102</span></p>
                  <p>Matrícula: <span className="text-[#00D4AA] font-mono">FSC-2955</span></p>
                  <p className="text-[var(--text-muted)]">Senha: qualquer</p>
                </div>
              ) : (
                <div className="text-xs text-[var(--text-secondary)] text-center space-y-1">
                  <p>Usuário: <span className="text-[#8B5CF6] font-mono">marcelo.sup</span></p>
                  <p className="text-[var(--text-muted)]">Senha: qualquer</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg-primary)] flex flex-col items-center justify-center px-6">
      {/* Logo */}
      <div className="mb-12 text-center">
        <h1 className="text-4xl font-bold mb-2">
          <span className="text-white">SI</span>
          <span className="text-[#00D4AA]">FU</span>
        </h1>
        <p className="text-[var(--text-secondary)] text-sm">Sistema Inteligente de Fiscalização Urbana</p>
      </div>

      {/* Title */}
      <h2 className="text-xl font-semibold text-[var(--text-primary)] mb-8">
        Como deseja acessar?
      </h2>

      {/* Profile Cards */}
      <div className="w-full max-w-sm space-y-4">
        {/* Cidadão */}
        <button
          onClick={() => onSelect('cidadao')}
          className="w-full p-5 rounded-2xl bg-gradient-to-r from-[#3B82F6]/20 to-[#3B82F6]/10 border border-[#3B82F6]/30 flex items-center gap-4 transition-all hover:scale-[1.02] active:scale-[0.98]"
        >
          <div className="w-14 h-14 rounded-xl bg-[#3B82F6]/20 flex items-center justify-center">
            <Users className="w-7 h-7 text-[#3B82F6]" />
          </div>
          <div className="text-left flex-1">
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Denunciante</h3>
            <p className="text-sm text-[var(--text-secondary)]">Registrar ou acompanhar denúncia</p>
          </div>
        </button>

        {/* Fiscal */}
        <button
          onClick={() => setShowLogin('fiscal')}
          className="w-full p-5 rounded-2xl bg-gradient-to-r from-[#00D4AA]/20 to-[#00D4AA]/10 border border-[#00D4AA]/30 flex items-center gap-4 transition-all hover:scale-[1.02] active:scale-[0.98]"
        >
          <div className="w-14 h-14 rounded-xl bg-[#00D4AA]/20 flex items-center justify-center">
            <Shield className="w-7 h-7 text-[#00D4AA]" />
          </div>
          <div className="text-left flex-1">
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Fiscal</h3>
            <p className="text-sm text-[var(--text-secondary)]">Vistorias, multas e relatórios</p>
          </div>
          <span className="text-xs text-[var(--text-muted)] bg-[var(--bg-card)] px-2 py-1 rounded">Login</span>
        </button>

        {/* Gerente */}
        <button
          onClick={() => setShowLogin('gerente')}
          className="w-full p-5 rounded-2xl bg-gradient-to-r from-[#8B5CF6]/20 to-[#8B5CF6]/10 border border-[#8B5CF6]/30 flex items-center gap-4 transition-all hover:scale-[1.02] active:scale-[0.98]"
        >
          <div className="w-14 h-14 rounded-xl bg-[#8B5CF6]/20 flex items-center justify-center">
            <Crown className="w-7 h-7 text-[#8B5CF6]" />
          </div>
          <div className="text-left flex-1">
            <h3 className="text-lg font-semibold text-[var(--text-primary)]">Gerente</h3>
            <p className="text-sm text-[var(--text-secondary)]">Gestão e designação</p>
          </div>
          <span className="text-xs text-[var(--text-muted)] bg-[var(--bg-card)] px-2 py-1 rounded">Login</span>
        </button>
      </div>

      {/* Footer */}
      <p className="mt-12 text-xs text-[var(--text-muted)] text-center">
        Prefeitura do Cabo de Santo Agostinho
      </p>
    </div>
  );
}
