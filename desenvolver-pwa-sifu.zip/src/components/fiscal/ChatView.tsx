import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Send } from 'lucide-react';
import { Profile, Denuncia, MensagemChat } from '@/types/database';
import { createMensagem, subscribe } from '@/lib/store';

interface ChatViewProps {
  user: Profile;
  denuncia: Denuncia;
  mensagens: MensagemChat[];
  onBack: () => void;
}

export function ChatView({ user, denuncia, mensagens: initialMensagens, onBack }: ChatViewProps) {
  const [mensagens, setMensagens] = useState(initialMensagens);
  const [texto, setTexto] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [mensagens]);

  useEffect(() => {
    const unsubscribe = subscribe('sifu_mensagens', () => {
      // In a real app, we'd refetch messages here
    });
    return () => { unsubscribe(); };
  }, []);

  const handleSend = () => {
    if (!texto.trim()) return;
    
    const newMsg = createMensagem({
      denuncia_id: denuncia.id,
      remetente_id: user.id,
      remetente_tipo: user.tipo as 'fiscal' | 'gerente',
      texto: texto.trim()
    });
    
    setMensagens(prev => [...prev, { ...newMsg, remetente: user }]);
    setTexto('');
  };

  return (
    <div className="min-h-screen bg-[var(--bg-primary)] flex flex-col">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-[var(--text-secondary)]">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="font-semibold text-[var(--text-primary)]">Chat — {denuncia.protocolo}</h1>
            <p className="text-xs text-[var(--text-secondary)]">
              {user.tipo === 'fiscal' ? 'Conversa com o Gerente' : 'Conversa com o Fiscal'}
            </p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-auto p-4 space-y-3">
        {mensagens.length === 0 && (
          <div className="text-center text-[var(--text-muted)] py-8">
            <p>Nenhuma mensagem ainda</p>
            <p className="text-sm">Inicie a conversa</p>
          </div>
        )}
        
        {mensagens.map(msg => {
          const isOwn = msg.remetente_id === user.id;
          return (
            <div 
              key={msg.id}
              className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[80%] ${
                isOwn 
                  ? (user.tipo === 'fiscal' ? 'chat-bubble-fiscal' : 'chat-bubble-gerente')
                  : (user.tipo === 'fiscal' ? 'chat-bubble-gerente' : 'chat-bubble-fiscal')
              } px-4 py-2`}>
                {!isOwn && (
                  <p className="text-xs opacity-70 mb-1">{msg.remetente?.nome || 'Usuário'}</p>
                )}
                <p className="text-white">{msg.texto}</p>
                <p className="text-xs opacity-50 text-right mt-1">
                  {new Date(msg.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Input */}
      <div className="bg-[var(--bg-card)] border-t border-[var(--border)] p-4 safe-bottom">
        <div className="flex gap-2">
          <input
            type="text"
            value={texto}
            onChange={e => setTexto(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            placeholder="Digite sua mensagem..."
            className="flex-1 px-4 py-3 rounded-xl"
          />
          <button
            onClick={handleSend}
            disabled={!texto.trim()}
            className="w-12 h-12 rounded-xl bg-gradient-to-r from-[#00D4AA] to-[#00B894] flex items-center justify-center disabled:opacity-50"
          >
            <Send size={20} className="text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}
