import { useState, useEffect } from 'react';
import { ArrowLeft, Bell, Check, FileText, MessageSquare, AlertTriangle, CheckCircle } from 'lucide-react';
import { Profile, Notificacao } from '@/types/database';
import { getNotificacoesByUser, markNotificacaoAsRead, markAllAsRead, subscribe } from '@/lib/store';

interface NotificacoesViewProps {
  user: Profile;
  onBack: () => void;
}

export function NotificacoesView({ user, onBack }: NotificacoesViewProps) {
  const [notificacoes, setNotificacoes] = useState<Notificacao[]>([]);

  useEffect(() => {
    loadNotificacoes();
    const unsubscribe = subscribe('sifu_notificacoes', loadNotificacoes);
    return () => { unsubscribe(); };
  }, [user.id]);

  const loadNotificacoes = () => {
    setNotificacoes(getNotificacoesByUser(user.id));
  };

  const handleMarkRead = (id: string) => {
    markNotificacaoAsRead(id);
    loadNotificacoes();
  };

  const handleMarkAllRead = () => {
    markAllAsRead(user.id);
    loadNotificacoes();
  };

  const getIcon = (tipo: string) => {
    switch(tipo) {
      case 'fiscal_designado':
        return <FileText className="text-[#00D4AA]" size={20} />;
      case 'mensagem_chat':
        return <MessageSquare className="text-[#3B82F6]" size={20} />;
      case 'prazo_vencendo':
      case 'prazo_vencido':
        return <AlertTriangle className="text-[#FF4757]" size={20} />;
      case 'aprovado':
        return <CheckCircle className="text-[#00D4AA]" size={20} />;
      case 'devolvido':
        return <AlertTriangle className="text-[#FFB020]" size={20} />;
      default:
        return <Bell className="text-[var(--text-muted)]" size={20} />;
    }
  };

  const unreadCount = notificacoes.filter(n => !n.lida).length;

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="text-[var(--text-secondary)]">
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-lg font-semibold text-[var(--text-primary)]">Notificações</h1>
          </div>
          {unreadCount > 0 && (
            <button 
              onClick={handleMarkAllRead}
              className="text-sm text-[#00D4AA]"
            >
              Marcar todas como lidas
            </button>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {notificacoes.length === 0 ? (
          <div className="bg-[var(--bg-card)] rounded-2xl p-8 text-center border border-[var(--border)]">
            <Bell size={48} className="mx-auto mb-4 text-[var(--text-muted)]" />
            <p className="text-[var(--text-secondary)]">Nenhuma notificação</p>
          </div>
        ) : (
          <div className="space-y-2">
            {notificacoes.map(notif => (
              <button
                key={notif.id}
                onClick={() => handleMarkRead(notif.id)}
                className={`w-full text-left bg-[var(--bg-card)] rounded-xl p-4 border transition-all ${
                  notif.lida 
                    ? 'border-[var(--border)] opacity-60' 
                    : 'border-[#00D4AA]/30 bg-[#00D4AA]/5'
                }`}
              >
                <div className="flex gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[var(--bg-card-secondary)] flex items-center justify-center flex-shrink-0">
                    {getIcon(notif.tipo)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <p className="font-medium text-[var(--text-primary)]">{notif.titulo}</p>
                      {!notif.lida && (
                        <span className="w-2 h-2 rounded-full bg-[#00D4AA] flex-shrink-0 mt-2" />
                      )}
                    </div>
                    <p className="text-sm text-[var(--text-secondary)] line-clamp-2">{notif.mensagem}</p>
                    <p className="text-xs text-[var(--text-muted)] mt-1">
                      {new Date(notif.created_at).toLocaleDateString('pt-BR')} às {new Date(notif.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
