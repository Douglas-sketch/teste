import { ArrowLeft, MapPin, Clock, AlertTriangle } from 'lucide-react';
import { Profile, Denuncia } from '@/types/database';

interface DenunciasListProps {
  user: Profile;
  denuncias: Denuncia[];
  onBack: () => void;
  onSelectDenuncia: (denuncia: Denuncia) => void;
}

export function DenunciasList({ denuncias, onBack, onSelectDenuncia }: DenunciasListProps) {
  const ativas = denuncias.filter(d => ['designada', 'em_vistoria'].includes(d.status));
  const concluidas = denuncias.filter(d => d.status === 'concluida');

  const getSlaInfo = (denuncia: Denuncia) => {
    if (!denuncia.prazo_sla_vence_em) return null;
    
    const remaining = new Date(denuncia.prazo_sla_vence_em).getTime() - Date.now();
    const hours = Math.floor(remaining / (1000 * 60 * 60));
    const isVencido = remaining < 0;
    const isUrgente = remaining < 4 * 60 * 60 * 1000;
    
    return { hours, isVencido, isUrgente };
  };

  const getPrioridadeStyle = (prioridade: string | null | undefined) => {
    switch(prioridade) {
      case 'urgente': return 'border-l-[#FF4757]';
      case 'alta': return 'border-l-[#FFB020]';
      default: return 'border-l-[#00D4AA]';
    }
  };

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-[var(--text-secondary)]">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-lg font-semibold text-[var(--text-primary)]">Denúncias Designadas</h1>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Ativas */}
        {ativas.length > 0 && (
          <div>
            <h2 className="text-sm font-medium text-[var(--text-secondary)] mb-3">
              Novas ({ativas.length})
            </h2>
            <div className="space-y-3">
              {ativas.map(denuncia => {
                const sla = getSlaInfo(denuncia);
                return (
                  <button
                    key={denuncia.id}
                    onClick={() => onSelectDenuncia(denuncia)}
                    className={`w-full bg-[var(--bg-card)] rounded-xl p-4 border border-[var(--border)] text-left border-l-4 ${getPrioridadeStyle(denuncia.prioridade)} ${
                      sla?.isUrgente ? 'animate-pulse-glow' : ''
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-semibold text-[var(--text-primary)]">{denuncia.protocolo}</p>
                        <span className={`badge ${
                          denuncia.prioridade === 'urgente' ? 'badge-urgente' :
                          denuncia.prioridade === 'alta' ? 'badge-alta' : 'badge-normal'
                        }`}>
                          {denuncia.prioridade || 'Normal'}
                        </span>
                      </div>
                      {sla && (
                        <div className={`text-xs ${sla.isVencido ? 'text-[#FF4757]' : sla.isUrgente ? 'text-[#FFB020]' : 'text-[var(--text-secondary)]'}`}>
                          {sla.isVencido ? (
                            <span className="flex items-center gap-1">
                              <AlertTriangle size={12} />
                              Vencido
                            </span>
                          ) : (
                            <span>{sla.hours > 24 ? `${Math.floor(sla.hours / 24)}d` : `${sla.hours}h`}</span>
                          )}
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-[var(--text-primary)] mb-1">{denuncia.tipo}</p>
                    <div className="flex items-center gap-1 text-sm text-[var(--text-secondary)]">
                      <MapPin size={14} />
                      <span className="truncate">{denuncia.endereco}</span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-[var(--text-muted)] mt-2">
                      <Clock size={12} />
                      <span>{new Date(denuncia.created_at).toLocaleDateString('pt-BR')}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {ativas.length === 0 && (
          <div className="bg-[#00D4AA]/10 border border-[#00D4AA]/30 rounded-2xl p-6 text-center">
            <p className="text-[#00D4AA] font-medium">✅ Nenhuma denúncia pendente</p>
            <p className="text-sm text-[var(--text-secondary)] mt-1">Todas as vistorias foram concluídas</p>
          </div>
        )}

        {/* Concluídas */}
        {concluidas.length > 0 && (
          <div>
            <h2 className="text-sm font-medium text-[var(--text-secondary)] mb-3">
              Concluídas ({concluidas.length})
            </h2>
            <div className="space-y-3 opacity-60">
              {concluidas.slice(0, 5).map(denuncia => (
                <button
                  key={denuncia.id}
                  onClick={() => onSelectDenuncia(denuncia)}
                  className="w-full bg-[var(--bg-card)] rounded-xl p-4 border border-[var(--border)] text-left"
                >
                  <div className="flex items-start justify-between mb-2">
                    <p className="font-semibold text-[var(--text-primary)]">{denuncia.protocolo}</p>
                    <span className="badge badge-concluida">Concluída</span>
                  </div>
                  <p className="text-sm text-[var(--text-secondary)] truncate">{denuncia.endereco}</p>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
