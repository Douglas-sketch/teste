import { useState } from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight, Folder, Search, BarChart3 } from 'lucide-react';
import { Profile } from '@/types/database';
import { getHistoricoByFiscal, getProdutividade } from '@/lib/store';

interface ProcessosViewProps {
  user: Profile;
  onBack: () => void;
}

const MESES = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

// Mock process counts
const MOCK_COUNTS = [12, 8, 15, 9, 11, 7, 13, 10, 6, 14, 8, 0];

export function ProcessosView({ user, onBack }: ProcessosViewProps) {
  const [ano, setAno] = useState(new Date().getFullYear());
  const [mesSelecionado, setMesSelecionado] = useState<number | null>(null);
  const [showProdutividade, setShowProdutividade] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const mesAtual = new Date().getMonth();

  if (showProdutividade && mesSelecionado !== null) {
    const prod = getProdutividade(user.id, mesSelecionado + 1, ano);
    const historico = getHistoricoByFiscal(user.id, mesSelecionado + 1, ano);

    return (
      <div className="min-h-screen bg-[var(--bg-primary)]">
        <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
          <div className="flex items-center gap-3">
            <button onClick={() => setShowProdutividade(false)} className="text-[var(--text-secondary)]">
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-lg font-semibold text-[var(--text-primary)]">Produtividade — {MESES[mesSelecionado]}</h1>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[var(--bg-card)] rounded-xl p-4 border border-[var(--border)] text-center">
              <p className="text-3xl font-bold text-[#00D4AA]">{prod.vistorias}</p>
              <p className="text-sm text-[var(--text-secondary)]">Vistorias</p>
            </div>
            <div className="bg-[var(--bg-card)] rounded-xl p-4 border border-[var(--border)] text-center">
              <p className="text-3xl font-bold text-[#FFB020]">{prod.autos}</p>
              <p className="text-sm text-[var(--text-secondary)]">Autos</p>
            </div>
            <div className="bg-[var(--bg-card)] rounded-xl p-4 border border-[var(--border)] text-center">
              <p className="text-3xl font-bold text-[#3B82F6]">
                R$ {prod.total_ganho.toLocaleString('pt-BR')}
              </p>
              <p className="text-sm text-[var(--text-secondary)]">Ganhos</p>
            </div>
            <div className="bg-[var(--bg-card)] rounded-xl p-4 border border-[var(--border)] text-center">
              <p className="text-3xl font-bold text-[#8B5CF6]">{prod.total_atividades}</p>
              <p className="text-sm text-[var(--text-secondary)]">Total</p>
            </div>
          </div>

          {/* Historico */}
          <div className="bg-[var(--bg-card)] rounded-2xl border border-[var(--border)] overflow-hidden">
            <div className="px-4 py-3 border-b border-[var(--border)]">
              <h3 className="font-semibold text-[var(--text-primary)]">Histórico de Atividades</h3>
            </div>
            {historico.length === 0 ? (
              <div className="p-8 text-center text-[var(--text-muted)]">
                Nenhuma atividade neste mês
              </div>
            ) : (
              <div className="divide-y divide-[var(--border)]">
                {historico.map(h => (
                  <div key={h.id} className="p-4 flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      h.tipo_atividade === 'vistoria' ? 'bg-[#00D4AA]/20 text-[#00D4AA]' :
                      h.tipo_atividade === 'auto_infracao' ? 'bg-[#FF4757]/20 text-[#FF4757]' :
                      'bg-[#3B82F6]/20 text-[#3B82F6]'
                    }`}>
                      {h.tipo_atividade === 'vistoria' ? '📋' : h.tipo_atividade === 'auto_infracao' ? '⚖️' : '📝'}
                    </div>
                    <div className="flex-1">
                      <p className="text-[var(--text-primary)]">{h.local_descricao || h.descricao}</p>
                      <p className="text-sm text-[var(--text-secondary)]">
                        {h.tipo_atividade.replace('_', ' ')} • {new Date(h.created_at).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                    {h.valor_ganho > 0 && (
                      <span className="text-[#00D4AA] font-medium">
                        +R$ {h.valor_ganho.toFixed(2)}
                      </span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Download button */}
          <button className="w-full py-4 rounded-xl bg-[var(--bg-card)] border border-[var(--border)] text-[var(--text-primary)] font-medium flex items-center justify-center gap-2">
            🤖 Download Relatório Completo (IA)
          </button>
        </div>
      </div>
    );
  }

  if (mesSelecionado !== null) {
    const historico = getHistoricoByFiscal(user.id, mesSelecionado + 1, ano);
    
    const filteredHistorico = searchQuery 
      ? historico.filter(h => 
          h.descricao.toLowerCase().includes(searchQuery.toLowerCase()) ||
          h.denuncia?.protocolo?.toLowerCase().includes(searchQuery.toLowerCase())
        )
      : historico;

    return (
      <div className="min-h-screen bg-[var(--bg-primary)]">
        <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
          <div className="flex items-center gap-3">
            <button onClick={() => setMesSelecionado(null)} className="text-[var(--text-secondary)]">
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-lg font-semibold text-[var(--text-primary)]">Processos de {MESES[mesSelecionado]}</h1>
          </div>
        </div>

        <div className="p-4 space-y-4">
          {/* Search */}
          <div className="relative">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)]" />
            <input
              type="text"
              placeholder="Buscar por protocolo ou descrição..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-3 rounded-xl"
            />
          </div>

          {/* List */}
          {filteredHistorico.length === 0 ? (
            <div className="bg-[var(--bg-card)] rounded-2xl p-8 text-center border border-[var(--border)]">
              <Folder size={48} className="mx-auto mb-4 text-[var(--text-muted)]" />
              <p className="text-[var(--text-secondary)]">Nenhum processo encontrado</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredHistorico.map(h => (
                <div 
                  key={h.id}
                  className="bg-[var(--bg-card)] rounded-xl p-4 border border-[var(--border)]"
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className="font-mono text-[#00D4AA]">{h.denuncia?.protocolo}</span>
                    <span className={`badge ${
                      h.tipo_atividade === 'vistoria' ? 'badge-em-vistoria' :
                      h.tipo_atividade === 'auto_infracao' ? 'badge-urgente' :
                      'badge-designada'
                    }`}>
                      {h.tipo_atividade.replace('_', ' ')}
                    </span>
                  </div>
                  <p className="text-sm text-[var(--text-primary)]">{h.denuncia?.tipo}</p>
                  <p className="text-sm text-[var(--text-secondary)] truncate">{h.local_descricao}</p>
                </div>
              ))}
            </div>
          )}

          {/* Produtividade button */}
          <button 
            onClick={() => setShowProdutividade(true)}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] text-white font-medium flex items-center justify-center gap-2"
          >
            <BarChart3 size={20} />
            📊 Acessar Minha Produtividade
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-[var(--text-secondary)]">
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-lg font-semibold text-[var(--text-primary)]">Processos</h1>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Year selector */}
        <div className="flex items-center justify-center gap-4">
          <button 
            onClick={() => setAno(ano - 1)}
            className="w-10 h-10 rounded-full bg-[var(--bg-card)] flex items-center justify-center text-[var(--text-secondary)]"
          >
            <ChevronLeft size={20} />
          </button>
          <span className="text-xl font-semibold text-[var(--text-primary)]">{ano}</span>
          <button 
            onClick={() => setAno(ano + 1)}
            disabled={ano >= new Date().getFullYear()}
            className="w-10 h-10 rounded-full bg-[var(--bg-card)] flex items-center justify-center text-[var(--text-secondary)] disabled:opacity-30"
          >
            <ChevronRight size={20} />
          </button>
        </div>

        {/* Months Grid */}
        <div className="grid grid-cols-3 gap-3">
          {MESES.map((mes, index) => {
            const count = ano === new Date().getFullYear() && index > mesAtual ? 0 : MOCK_COUNTS[index];
            const isFuture = ano === new Date().getFullYear() && index > mesAtual;
            
            return (
              <button
                key={mes}
                onClick={() => !isFuture && setMesSelecionado(index)}
                disabled={isFuture}
                className={`p-4 rounded-xl border text-center transition-all ${
                  isFuture 
                    ? 'opacity-30 cursor-not-allowed bg-[var(--bg-card)] border-[var(--border)]'
                    : 'bg-[var(--bg-card)] border-[var(--border)] hover:border-[#00D4AA] active:scale-[0.98]'
                }`}
              >
                <Folder size={24} className={`mx-auto mb-2 ${count > 0 ? 'text-[#00D4AA]' : 'text-[var(--text-muted)]'}`} />
                <p className="text-sm text-[var(--text-primary)]">{mes.substring(0, 3)}</p>
                <p className={`text-xs ${count > 0 ? 'text-[#00D4AA]' : 'text-[var(--text-muted)]'}`}>
                  {count} processos
                </p>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
