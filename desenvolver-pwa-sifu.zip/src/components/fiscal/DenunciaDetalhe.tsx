import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, MapPin, Clock, User, FileText, Camera, Scale, MessageSquare, Check, AlertTriangle, Navigation } from 'lucide-react';
import { Profile, Denuncia, Foto, TIPOS_DENUNCIA, GRAUS_INFRACAO } from '@/types/database';
import { 
  getFotosByDenuncia, 
  getHistoricoEndereco, 
  iniciarVistoria,
  createRelatorio,
  createAuto,
  createFoto,
  getMensagensByDenuncia,
  createMensagem,
  subscribe
} from '@/lib/store';
import { ChatView } from './ChatView';

interface DenunciaDetalheProps {
  user: Profile;
  denuncia: Denuncia;
  onBack: () => void;
  onUpdate: () => void;
}

type Modal = null | 'relatorio' | 'auto' | 'fotos' | 'assinatura' | 'chat';

export function DenunciaDetalhe({ user, denuncia, onBack, onUpdate }: DenunciaDetalheProps) {
  const [modal, setModal] = useState<Modal>(null);
  const [fotos, setFotos] = useState<Foto[]>([]);
  const [loading, setLoading] = useState(false);

  // Relatorio state
  const [tipoRelatorio, setTipoRelatorio] = useState('');
  const [situacao, setSituacao] = useState('');
  const [providencias, setProvidencias] = useState('');
  const [observacoes, setObservacoes] = useState('');
  const [relatorioFotos, setRelatorioFotos] = useState<string[]>([]);

  // Auto state
  const [infracaoTipo, setInfracaoTipo] = useState(denuncia.tipo);
  const [valorBase, setValorBase] = useState(0);
  const [grau, setGrau] = useState('grave');
  const [grauMulti, setGrauMulti] = useState(1.5);
  const [reincidencia, setReincidencia] = useState(false);
  const [autoObservacoes, setAutoObservacoes] = useState('');

  // Assinatura state
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [pendingRelatorio, setPendingRelatorio] = useState<any>(null);

  const historico = getHistoricoEndereco(denuncia.endereco);
  const mensagens = getMensagensByDenuncia(denuncia.id);

  useEffect(() => {
    setFotos(getFotosByDenuncia(denuncia.id, 'denuncia'));
    
    // Auto-fill based on tipo
    const tipo = TIPOS_DENUNCIA.find(t => t.codigo === denuncia.tipo_codigo);
    if (tipo) {
      setTipoRelatorio(tipo.tipoRelatorio);
      setSituacao(tipo.templateSituacao);
      setProvidencias(tipo.templateProvidencias);
      setValorBase(tipo.valorMulta);
      setInfracaoTipo(tipo.label);
    }
    
    // Check reincidencia
    if (historico.total_ocorrencias > 1) {
      setReincidencia(true);
    }
  }, [denuncia]);

  // Subscribe to updates
  useEffect(() => {
    const unsubscribe = subscribe('sifu_mensagens', () => {
      // Refresh messages
    });
    return () => { unsubscribe(); };
  }, []);

  const handleCheckin = () => {
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        iniciarVistoria(denuncia.id, position.coords.latitude, position.coords.longitude);
        onUpdate();
        setLoading(false);
      },
      () => {
        // Fallback with approximate location
        iniciarVistoria(denuncia.id, -8.28 + Math.random() * 0.01, -35.02 + Math.random() * 0.01);
        onUpdate();
        setLoading(false);
      }
    );
  };

  const handleSaveRelatorio = () => {
    const relatorioData = {
      denuncia_id: denuncia.id,
      fiscal_id: user.id,
      tipo_relatorio: tipoRelatorio,
      situacao_encontrada: situacao,
      providencias_adotadas: providencias,
      observacoes: observacoes || null,
      status_aprovacao: 'pendente' as const
    };
    
    setPendingRelatorio(relatorioData);
    setModal('assinatura');
  };

  const handleConfirmAssinatura = () => {
    const canvas = canvasRef.current;
    let assinaturaUrl: string | null = null;
    
    if (canvas) {
      assinaturaUrl = canvas.toDataURL('image/png');
    }
    
    createRelatorio({
      ...pendingRelatorio,
      assinatura_url: assinaturaUrl,
      assinatura_dados: assinaturaUrl ? {
        data: new Date().toLocaleDateString('pt-BR'),
        hora: new Date().toLocaleTimeString('pt-BR'),
        fiscal_nome: user.nome,
        protocolo: denuncia.protocolo
      } : null
    });
    
    // Save photos
    relatorioFotos.forEach((url, i) => {
      createFoto({
        denuncia_id: denuncia.id,
        uploaded_by: user.id,
        tipo: 'relatorio',
        url,
        ordem: i
      });
    });
    
    setModal(null);
    setPendingRelatorio(null);
    onUpdate();
    onBack();
  };

  const handleSaveAuto = () => {
    const reincMulti = reincidencia ? 2 : 1;
    const valorTotal = valorBase * grauMulti * reincMulti;
    
    createAuto({
      denuncia_id: denuncia.id,
      fiscal_id: user.id,
      infracao_tipo: infracaoTipo,
      valor_base: valorBase,
      grau,
      grau_multiplicador: grauMulti,
      reincidencia,
      reincidencia_multiplicador: reincMulti,
      valor_total: valorTotal,
      valor_editado: false,
      fundamento_legal: 'Art. 127 — Código de Posturas',
      prazo_recurso_dias: 30,
      observacoes: autoObservacoes || null,
      status: 'emitido',
      status_aprovacao: 'pendente'
    });
    
    setModal(null);
    onUpdate();
    onBack();
  };

  // Canvas drawing handlers
  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  // Photo upload handler
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    Array.from(files).forEach(file => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setRelatorioFotos(prev => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const valorTotal = valorBase * grauMulti * (reincidencia ? 2 : 1);

  if (modal === 'chat') {
    return (
      <ChatView 
        user={user}
        denuncia={denuncia}
        mensagens={mensagens}
        onBack={() => setModal(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-[var(--text-secondary)]">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-lg font-semibold text-[var(--text-primary)]">{denuncia.protocolo}</h1>
            <span className={`badge ${
              denuncia.prioridade === 'urgente' ? 'badge-urgente' :
              denuncia.prioridade === 'alta' ? 'badge-alta' : 'badge-normal'
            }`}>
              {denuncia.prioridade || 'Normal'}
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4 pb-32">
        {/* Info Card */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)] space-y-3">
          <div className="flex items-start gap-2">
            <FileText size={16} className="text-[var(--text-muted)] mt-0.5" />
            <div>
              <span className="text-sm text-[var(--text-secondary)]">Tipo: </span>
              <span className="text-[var(--text-primary)]">{denuncia.tipo}</span>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <User size={16} className="text-[var(--text-muted)] mt-0.5" />
            <div>
              <span className="text-sm text-[var(--text-secondary)]">Denunciante: </span>
              <span className="text-[var(--text-primary)]">{denuncia.denunciante_nome}</span>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <MapPin size={16} className="text-[var(--text-muted)] mt-0.5" />
            <div>
              <span className="text-sm text-[var(--text-secondary)]">Local: </span>
              <span className="text-[var(--text-primary)]">{denuncia.endereco}</span>
              {denuncia.ponto_referencia && (
                <p className="text-sm text-[var(--text-muted)]">Ref: {denuncia.ponto_referencia}</p>
              )}
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Clock size={16} className="text-[var(--text-muted)] mt-0.5" />
            <div>
              <span className="text-sm text-[var(--text-secondary)]">Data: </span>
              <span className="text-[var(--text-primary)]">
                {new Date(denuncia.created_at).toLocaleDateString('pt-BR')} às {new Date(denuncia.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
          {denuncia.gerente && (
            <div className="flex items-start gap-2">
              <User size={16} className="text-[var(--text-muted)] mt-0.5" />
              <div>
                <span className="text-sm text-[var(--text-secondary)]">Designado por: </span>
                <span className="text-[var(--text-primary)]">{denuncia.gerente.nome}</span>
              </div>
            </div>
          )}
        </div>

        {/* Descrição */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
          <h3 className="text-sm text-[var(--text-secondary)] mb-2">Descrição do denunciante</h3>
          <p className="text-[var(--text-primary)]">{denuncia.descricao}</p>
        </div>

        {/* SLA */}
        {denuncia.prazo_sla_vence_em && denuncia.status !== 'concluida' && (
          <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
            <SlaBar denuncia={denuncia} />
          </div>
        )}

        {/* Fotos do denunciante */}
        {fotos.length > 0 && (
          <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
            <h3 className="text-sm text-[var(--text-secondary)] mb-3">Fotos do denunciante</h3>
            <div className="flex gap-2 overflow-x-auto hide-scrollbar">
              {fotos.map(foto => (
                <img 
                  key={foto.id}
                  src={foto.url_marca_dagua || foto.url}
                  alt=""
                  className="w-20 h-20 rounded-lg object-cover flex-shrink-0"
                />
              ))}
            </div>
          </div>
        )}

        {/* Histórico */}
        {historico.total_ocorrencias > 1 && (
          <div className="bg-[#FFB020]/10 border border-[#FFB020]/30 rounded-2xl p-4">
            <div className="flex items-center gap-2 text-[#FFB020] mb-2">
              <AlertTriangle size={18} />
              <span className="font-medium">⚠️ Reincidente — {historico.total_ocorrencias} ocorrências</span>
            </div>
            <div className="space-y-1">
              {historico.protocolos.slice(0, 3).filter(p => p !== denuncia.protocolo).map((prot, i) => (
                <p key={prot} className="text-sm text-[var(--text-secondary)]">
                  {prot} — {historico.tipos[i]}
                </p>
              ))}
            </div>
          </div>
        )}

        {/* DWG Map */}
        <DWGMap denuncia={denuncia} />
      </div>

      {/* Bottom Actions */}
      {denuncia.status !== 'concluida' && denuncia.status !== 'aguardando_aprovacao' && (
        <div className="fixed bottom-0 left-0 right-0 bg-[var(--bg-card)] border-t border-[var(--border)] p-4 safe-bottom">
          {denuncia.status === 'designada' ? (
            <button
              onClick={handleCheckin}
              disabled={loading}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-[#00D4AA] to-[#00B894] font-semibold text-white flex items-center justify-center gap-2"
            >
              <Navigation size={20} />
              {loading ? 'Obtendo localização...' : '📍 Check-in no local'}
            </button>
          ) : (
            <div className="space-y-2">
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => setModal('relatorio')}
                  className="py-3 rounded-xl bg-[#00D4AA]/20 text-[#00D4AA] font-medium flex flex-col items-center gap-1"
                >
                  <FileText size={20} />
                  <span className="text-xs">Relatório</span>
                </button>
                <button
                  onClick={() => setModal('fotos')}
                  className="py-3 rounded-xl bg-[#3B82F6]/20 text-[#3B82F6] font-medium flex flex-col items-center gap-1"
                >
                  <Camera size={20} />
                  <span className="text-xs">Fotos</span>
                </button>
                <button
                  onClick={() => setModal('auto')}
                  className="py-3 rounded-xl bg-[#FF4757]/20 text-[#FF4757] font-medium flex flex-col items-center gap-1"
                >
                  <Scale size={20} />
                  <span className="text-xs">Auto</span>
                </button>
              </div>
              <button
                onClick={() => setModal('chat')}
                className="w-full py-3 rounded-xl bg-[var(--bg-card-secondary)] text-[var(--text-primary)] font-medium flex items-center justify-center gap-2"
              >
                <MessageSquare size={18} />
                Chat com Gerente
                {mensagens.length > 0 && (
                  <span className="w-5 h-5 rounded-full bg-[#8B5CF6] text-white text-xs flex items-center justify-center">
                    {mensagens.length}
                  </span>
                )}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Relatório Modal */}
      {modal === 'relatorio' && (
        <div className="fixed inset-0 bg-black/80 z-50 overflow-auto">
          <div className="min-h-screen bg-[var(--bg-primary)] animate-slide-up">
            <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 sticky top-0">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-[var(--text-primary)]">Elaborar Relatório</h2>
                <button onClick={() => setModal(null)} className="text-[var(--text-secondary)]">✕</button>
              </div>
            </div>
            <div className="p-4 space-y-4 pb-24">
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">Tipo de relatório</label>
                <select
                  value={tipoRelatorio}
                  onChange={e => setTipoRelatorio(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl"
                >
                  {TIPOS_DENUNCIA.map(t => (
                    <option key={t.codigo} value={t.tipoRelatorio}>{t.tipoRelatorio}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">Situação encontrada *</label>
                <textarea
                  value={situacao}
                  onChange={e => setSituacao(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl resize-none"
                />
              </div>
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">Providências adotadas *</label>
                <textarea
                  value={providencias}
                  onChange={e => setProvidencias(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl resize-none"
                />
              </div>
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">Observações</label>
                <textarea
                  value={observacoes}
                  onChange={e => setObservacoes(e.target.value)}
                  rows={2}
                  className="w-full px-4 py-3 rounded-xl resize-none"
                  placeholder="Opcional"
                />
              </div>
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-2 block">Fotos do relatório</label>
                <div className="flex gap-2 flex-wrap">
                  {relatorioFotos.map((url, i) => (
                    <div key={i} className="w-20 h-20 rounded-lg overflow-hidden relative">
                      <img src={url} alt="" className="w-full h-full object-cover" />
                      <button 
                        onClick={() => setRelatorioFotos(prev => prev.filter((_, idx) => idx !== i))}
                        className="absolute top-1 right-1 w-5 h-5 rounded-full bg-[#FF4757] text-white text-xs"
                      >✕</button>
                    </div>
                  ))}
                  <label className="w-20 h-20 rounded-lg bg-[var(--bg-card-secondary)] flex items-center justify-center cursor-pointer">
                    <Camera className="text-[var(--text-muted)]" />
                    <input type="file" accept="image/*" multiple onChange={handlePhotoUpload} className="hidden" />
                  </label>
                </div>
              </div>
            </div>
            <div className="fixed bottom-0 left-0 right-0 bg-[var(--bg-card)] border-t border-[var(--border)] p-4">
              <button
                onClick={handleSaveRelatorio}
                disabled={!situacao || !providencias}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-[#00D4AA] to-[#00B894] font-semibold text-white disabled:opacity-50"
              >
                Continuar para Assinatura
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Assinatura Modal */}
      {modal === 'assinatura' && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[var(--bg-card)] rounded-2xl p-6 w-full max-w-sm">
            <h2 className="text-lg font-semibold text-[var(--text-primary)] mb-4 text-center">Assinatura Digital</h2>
            <p className="text-sm text-[var(--text-secondary)] mb-4 text-center">
              Assine no campo abaixo (ou pule esta etapa)
            </p>
            <canvas
              ref={canvasRef}
              width={280}
              height={150}
              className="w-full bg-white rounded-xl mb-4 touch-none"
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
              onTouchStart={startDrawing}
              onTouchMove={draw}
              onTouchEnd={stopDrawing}
            />
            <div className="flex gap-2 mb-4">
              <button
                onClick={clearCanvas}
                className="flex-1 py-2 rounded-lg bg-[var(--bg-card-secondary)] text-[var(--text-secondary)]"
              >
                Limpar
              </button>
            </div>
            <div className="space-y-2">
              <button
                onClick={handleConfirmAssinatura}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#00D4AA] to-[#00B894] font-semibold text-white flex items-center justify-center gap-2"
              >
                <Check size={18} />
                Confirmar e Enviar
              </button>
              <button
                onClick={() => { handleConfirmAssinatura(); }}
                className="w-full py-3 rounded-xl bg-[var(--bg-card-secondary)] text-[var(--text-secondary)]"
              >
                Pular assinatura
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Auto Modal */}
      {modal === 'auto' && (
        <div className="fixed inset-0 bg-black/80 z-50 overflow-auto">
          <div className="min-h-screen bg-[var(--bg-primary)] animate-slide-up">
            <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 sticky top-0">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-[var(--text-primary)]">Auto de Infração</h2>
                <button onClick={() => setModal(null)} className="text-[var(--text-secondary)]">✕</button>
              </div>
            </div>
            <div className="p-4 space-y-4 pb-24">
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">Tipo de infração</label>
                <select
                  value={infracaoTipo}
                  onChange={e => {
                    setInfracaoTipo(e.target.value);
                    const tipo = TIPOS_DENUNCIA.find(t => t.label === e.target.value);
                    if (tipo) setValorBase(tipo.valorMulta);
                  }}
                  className="w-full px-4 py-3 rounded-xl"
                >
                  {TIPOS_DENUNCIA.map(t => (
                    <option key={t.codigo} value={t.label}>{t.label} — R$ {t.valorMulta.toLocaleString('pt-BR')}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">Grau da infração</label>
                <div className="grid grid-cols-3 gap-2">
                  {GRAUS_INFRACAO.map(g => (
                    <button
                      key={g.value}
                      onClick={() => { setGrau(g.value); setGrauMulti(g.multiplicador); }}
                      className={`py-3 rounded-xl border text-center ${
                        grau === g.value 
                          ? 'bg-[#00D4AA]/20 border-[#00D4AA] text-[#00D4AA]' 
                          : 'bg-[var(--bg-card)] border-[var(--border)] text-[var(--text-primary)]'
                      }`}
                    >
                      <p className="font-medium">{g.label}</p>
                      <p className="text-xs opacity-70">{g.multiplicador}x</p>
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">Reincidência</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setReincidencia(false)}
                    className={`py-3 rounded-xl border ${
                      !reincidencia 
                        ? 'bg-[#00D4AA]/20 border-[#00D4AA] text-[#00D4AA]' 
                        : 'bg-[var(--bg-card)] border-[var(--border)] text-[var(--text-primary)]'
                    }`}
                  >
                    Primeira vez (1x)
                  </button>
                  <button
                    onClick={() => setReincidencia(true)}
                    className={`py-3 rounded-xl border ${
                      reincidencia 
                        ? 'bg-[#FF4757]/20 border-[#FF4757] text-[#FF4757]' 
                        : 'bg-[var(--bg-card)] border-[var(--border)] text-[var(--text-primary)]'
                    }`}
                  >
                    Reincidente (2x)
                  </button>
                </div>
              </div>

              {/* Valor Total */}
              <div className="bg-[var(--bg-card)] rounded-2xl p-5 border border-[var(--border)] text-center">
                <p className="text-sm text-[var(--text-secondary)] mb-2">Valor Total da Multa</p>
                <p className="text-4xl font-bold text-[#00D4AA]">
                  R$ {valorTotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-[var(--text-muted)] mt-2">
                  Base R$ {valorBase.toLocaleString('pt-BR')} × {grauMulti}x × {reincidencia ? '2x' : '1x'}
                </p>
              </div>

              <div className="bg-[var(--bg-card-secondary)] rounded-xl p-3 text-center">
                <p className="text-sm text-[var(--text-secondary)]">📋 30 dias para recurso</p>
                <p className="text-xs text-[var(--text-muted)]">Art. 127 — Código de Posturas</p>
              </div>

              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">Observações</label>
                <textarea
                  value={autoObservacoes}
                  onChange={e => setAutoObservacoes(e.target.value)}
                  rows={2}
                  className="w-full px-4 py-3 rounded-xl resize-none"
                  placeholder="Opcional"
                />
              </div>
            </div>
            <div className="fixed bottom-0 left-0 right-0 bg-[var(--bg-card)] border-t border-[var(--border)] p-4">
              <button
                onClick={handleSaveAuto}
                className="w-full py-4 rounded-xl bg-gradient-to-r from-[#FF4757] to-[#FF2D2D] font-semibold text-white"
              >
                ⚖️ Emitir Auto de Infração
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fotos Modal */}
      {modal === 'fotos' && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-[var(--bg-card)] rounded-2xl p-6 w-full max-w-sm">
            <h2 className="text-lg font-semibold text-[var(--text-primary)] mb-4">Anexar Fotos da Vistoria</h2>
            <label className="w-full py-8 rounded-xl bg-[var(--bg-card-secondary)] border-2 border-dashed border-[var(--border)] flex flex-col items-center justify-center cursor-pointer mb-4">
              <Camera size={32} className="text-[var(--text-muted)] mb-2" />
              <span className="text-[var(--text-secondary)]">Tirar foto ou escolher</span>
              <input 
                type="file" 
                accept="image/*" 
                capture="environment" 
                multiple 
                onChange={(e) => {
                  // Handle upload...
                  setModal(null);
                }} 
                className="hidden" 
              />
            </label>
            <button
              onClick={() => setModal(null)}
              className="w-full py-3 rounded-xl bg-[var(--bg-card-secondary)] text-[var(--text-secondary)]"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// SLA Bar component
function SlaBar({ denuncia }: { denuncia: Denuncia }) {
  if (!denuncia.prazo_sla_vence_em) return null;
  
  const now = new Date();
  const deadline = new Date(denuncia.prazo_sla_vence_em);
  const designada = new Date(denuncia.designada_at || denuncia.created_at);
  const total = deadline.getTime() - designada.getTime();
  const remaining = deadline.getTime() - now.getTime();
  const percentage = Math.max(0, Math.min(100, (remaining / total) * 100));
  
  const hoursRemaining = Math.floor(remaining / (1000 * 60 * 60));
  const isVencido = remaining < 0;
  
  let color = 'sla-green';
  if (percentage < 20) color = 'sla-red';
  else if (percentage < 50) color = 'sla-yellow';

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm text-[var(--text-secondary)]">Prazo SLA</span>
        {isVencido ? (
          <span className="text-[#FF4757] text-sm font-medium">⚠️ Vencido há {Math.abs(hoursRemaining)}h</span>
        ) : (
          <span className="text-[var(--text-primary)] text-sm font-medium">
            {hoursRemaining > 24 ? `${Math.floor(hoursRemaining / 24)} dias` : `${hoursRemaining}h`} restantes
          </span>
        )}
      </div>
      <div className="progress-bar">
        <div className={`progress-bar-fill ${color}`} style={{ width: `${percentage}%` }} />
      </div>
    </div>
  );
}

// DWG Map component
function DWGMap({ denuncia }: { denuncia: Denuncia }) {
  return (
    <div className="dwg-map rounded-2xl overflow-hidden">
      <div className="dwg-grid" />
      <div className="relative p-4 h-48">
        <div className="absolute top-2 right-2 badge bg-[#00D4AA]/20 text-[#00D4AA]">
          SOBREPOSIÇÃO DWG
        </div>
        
        {/* Simulated DWG lots */}
        <div className="absolute inset-4 flex items-center justify-center">
          <div className="grid grid-cols-4 gap-1 w-full max-w-xs">
            {[1,2,3,4,5,6,7,8].map(i => (
              <div 
                key={i}
                className={`h-12 rounded border flex items-center justify-center text-xs ${
                  i === 3 
                    ? 'border-[#FF4757] bg-[#FF4757]/15 text-[#FF4757]' 
                    : 'border-[#00D4AA]/40 bg-[#00D4AA]/5 text-[var(--text-muted)]'
                }`}
              >
                Q1-L{i.toString().padStart(2, '0')}
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="bg-[#0d1a0d] px-4 py-2 flex items-center justify-between">
        <span className="text-xs text-[var(--text-secondary)]">
          Quadra 1 — Lote 03 | {denuncia.endereco.substring(0, 25)}...
        </span>
        <span className="text-xs text-[#FF4757]">⚠️ Irregular</span>
      </div>
    </div>
  );
}
