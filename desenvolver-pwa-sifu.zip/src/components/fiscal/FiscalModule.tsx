import { useState, useEffect } from 'react';
import { LogOut, FileText, FolderOpen, Bell, ChevronRight, MapPin, Clock, AlertTriangle } from 'lucide-react';
import { Profile, Denuncia } from '@/types/database';
import { getDenunciasByFiscal, getProdutividade, getUnreadCount, subscribe } from '@/lib/store';
import { DenunciasList } from './DenunciasList';
import { DenunciaDetalhe } from './DenunciaDetalhe';
import { ProcessosView } from './ProcessosView';
import { NotificacoesView } from './NotificacoesView';

interface FiscalModuleProps {
  user: Profile;
  onLogout: () => void;
}

type Screen = 'home' | 'denuncias' | 'denuncia-detalhe' | 'processos' | 'notificacoes';

export function FiscalModule({ user, onLogout }: FiscalModuleProps) {
  const [screen, setScreen] = useState<Screen>('home');
  const [selectedDenuncia, setSelectedDenuncia] = useState<Denuncia | null>(null);
  const [denuncias, setDenuncias] = useState<Denuncia[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  const now = new Date();
  const produtividade = getProdutividade(user.id, now.getMonth() + 1, now.getFullYear());

  useEffect(() => {
    loadData();
    const unsubscribe = subscribe('*', loadData);
    return () => { unsubscribe(); };
  }, [user.id]);

  const loadData = () => {
    setDenuncias(getDenunciasByFiscal(user.id));
    setUnreadCount(getUnreadCount(user.id));
  };

  const ativasCount = denuncias.filter(d => ['designada', 'em_vistoria'].includes(d.status)).length;

  // Get urgentes
  const urgentes = denuncias.filter(d => {
    if (d.status !== 'designada' && d.status !== 'em_vistoria') return false;
    if (!d.prazo_sla_vence_em) return false;
    const remaining = new Date(d.prazo_sla_vence_em).getTime() - Date.now();
    return remaining < 4 * 60 * 60 * 1000; // < 4 hours
  });

  if (screen === 'denuncias') {
    return (
      <DenunciasList 
        user={user}
        denuncias={denuncias}
        onBack={() => setScreen('home')}
        onSelectDenuncia={(d) => { setSelectedDenuncia(d); setScreen('denuncia-detalhe'); }}
      />
    );
  }

  if (screen === 'denuncia-detalhe' && selectedDenuncia) {
    return (
      <DenunciaDetalhe 
        user={user}
        denuncia={selectedDenuncia}
        onBack={() => { setScreen('denuncias'); setSelectedDenuncia(null); }}
        onUpdate={loadData}
      />
    );
  }

  if (screen === 'processos') {
    return <ProcessosView user={user} onBack={() => setScreen('home')} />;
  }

  if (screen === 'notificacoes') {
    return <NotificacoesView user={user} onBack={() => setScreen('home')} />;
  }

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold"
              style={{ backgroundColor: user.avatar_color }}
            >
              {user.avatar_initials}
            </div>
            <div>
              <p className="text-sm text-[var(--text-secondary)]">Olá,</p>
              <h1 className="font-semibold text-[var(--text-primary)]">{user.nome.split(' ')[0]} 👋</h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setScreen('notificacoes')}
              className="relative w-10 h-10 rounded-full bg-[var(--bg-card-secondary)] flex items-center justify-center"
            >
              <Bell size={20} className="text-[var(--text-secondary)]" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#FF4757] text-white text-xs flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>
            <button 
              onClick={onLogout}
              className="w-10 h-10 rounded-full bg-[var(--bg-card-secondary)] flex items-center justify-center"
            >
              <LogOut size={20} className="text-[var(--text-secondary)]" />
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Urgentes Alert */}
        {urgentes.length > 0 && (
          <div className="bg-[#FF4757]/10 border border-[#FF4757]/30 rounded-2xl p-4">
            <div className="flex items-center gap-2 text-[#FF4757] mb-2">
              <AlertTriangle size={20} />
              <span className="font-semibold">{urgentes.length} prazo(s) vencendo!</span>
            </div>
            <p className="text-sm text-[var(--text-secondary)]">
              Você tem denúncias com prazo crítico
            </p>
          </div>
        )}

        {/* What to do today */}
        <h2 className="text-lg font-semibold text-[var(--text-primary)]">
          O que vai ser hoje?
        </h2>

        {/* Main Actions */}
        <div className="grid grid-cols-2 gap-3">
          {/* Denúncias */}
          <button
            onClick={() => setScreen('denuncias')}
            className="p-5 rounded-2xl bg-gradient-to-br from-[#00D4AA]/20 to-[#00D4AA]/5 border border-[#00D4AA]/30 text-left transition-all active:scale-[0.98] relative"
          >
            <div className="w-12 h-12 rounded-xl bg-[#00D4AA]/20 flex items-center justify-center mb-3">
              <FileText className="w-6 h-6 text-[#00D4AA]" />
            </div>
            <h3 className="font-semibold text-[var(--text-primary)]">Denúncias</h3>
            <p className="text-xs text-[var(--text-secondary)] mt-1">Vistorias pendentes</p>
            {ativasCount > 0 && (
              <span className="absolute top-4 right-4 w-6 h-6 rounded-full bg-[#00D4AA] text-white text-sm flex items-center justify-center font-medium">
                {ativasCount}
              </span>
            )}
          </button>

          {/* Processos */}
          <button
            onClick={() => setScreen('processos')}
            className="p-5 rounded-2xl bg-gradient-to-br from-[#3B82F6]/20 to-[#3B82F6]/5 border border-[#3B82F6]/30 text-left transition-all active:scale-[0.98]"
          >
            <div className="w-12 h-12 rounded-xl bg-[#3B82F6]/20 flex items-center justify-center mb-3">
              <FolderOpen className="w-6 h-6 text-[#3B82F6]" />
            </div>
            <h3 className="font-semibold text-[var(--text-primary)]">Processos</h3>
            <p className="text-xs text-[var(--text-secondary)] mt-1">Histórico e relatórios</p>
          </button>
        </div>

        {/* Month Summary */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-5 border border-[var(--border)]">
          <h3 className="font-semibold text-[var(--text-primary)] mb-4">Resumo do mês</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-[#00D4AA]">{produtividade.vistorias}</p>
              <p className="text-xs text-[var(--text-secondary)]">Vistorias</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-[#FFB020]">{produtividade.autos}</p>
              <p className="text-xs text-[var(--text-secondary)]">Autos</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-[#3B82F6]">{produtividade.total_atividades}</p>
              <p className="text-xs text-[var(--text-secondary)]">Total</p>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        {denuncias.length > 0 && (
          <div className="bg-[var(--bg-card)] rounded-2xl border border-[var(--border)] overflow-hidden">
            <div className="px-4 py-3 border-b border-[var(--border)]">
              <h3 className="font-semibold text-[var(--text-primary)]">Atividade recente</h3>
            </div>
            <div className="divide-y divide-[var(--border)]">
              {denuncias.slice(0, 3).map(d => (
                <button
                  key={d.id}
                  onClick={() => { setSelectedDenuncia(d); setScreen('denuncia-detalhe'); }}
                  className="w-full p-4 flex items-center gap-3 text-left hover:bg-[var(--bg-card-secondary)] transition-colors"
                >
                  <div className={`w-2 h-2 rounded-full ${
                    d.prioridade === 'urgente' ? 'bg-[#FF4757]' : 
                    d.prioridade === 'alta' ? 'bg-[#FFB020]' : 'bg-[#00D4AA]'
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-[var(--text-primary)] truncate">{d.protocolo}</p>
                    <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
                      <MapPin size={12} />
                      <span className="truncate">{d.endereco}</span>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-[var(--text-muted)]" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Status */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full ${
                user.status_online === 'em_campo' ? 'bg-[#00D4AA]' : 'bg-[var(--text-muted)]'
              }`} />
              <span className="text-sm text-[var(--text-secondary)]">
                {user.status_online === 'em_campo' ? 'Em campo' : 'No escritório'}
              </span>
            </div>
            <span className="text-xs text-[var(--text-muted)]">
              <Clock size={12} className="inline mr-1" />
              {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
