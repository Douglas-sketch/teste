import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { CheckCircle, XCircle, AlertCircle, Info, X } from 'lucide-react';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
}

interface ToastContextType {
  showToast: (type: Toast['type'], title: string, message?: string) => void;
}

const ToastContext = createContext<ToastContextType | null>(null);

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within ToastProvider');
  }
  return context;
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = (type: Toast['type'], title: string, message?: string) => {
    const id = crypto.randomUUID();
    setToasts(prev => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  };

  const removeToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed bottom-4 left-4 right-4 z-50 flex flex-col gap-2 pointer-events-none">
        {toasts.map(toast => (
          <ToastItem key={toast.id} toast={toast} onClose={() => removeToast(toast.id)} />
        ))}
      </div>
    </ToastContext.Provider>
  );
}

function ToastItem({ toast, onClose }: { toast: Toast; onClose: () => void }) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setTimeout(() => setIsVisible(true), 10);
  }, []);

  const icons = {
    success: <CheckCircle className="w-5 h-5 text-[#00D4AA]" />,
    error: <XCircle className="w-5 h-5 text-[#FF4757]" />,
    warning: <AlertCircle className="w-5 h-5 text-[#FFB020]" />,
    info: <Info className="w-5 h-5 text-[#3B82F6]" />
  };

  const bgColors = {
    success: 'bg-[#00D4AA]/10 border-[#00D4AA]/30',
    error: 'bg-[#FF4757]/10 border-[#FF4757]/30',
    warning: 'bg-[#FFB020]/10 border-[#FFB020]/30',
    info: 'bg-[#3B82F6]/10 border-[#3B82F6]/30'
  };

  return (
    <div 
      className={`pointer-events-auto ${bgColors[toast.type]} border rounded-xl p-4 flex items-start gap-3 transition-all duration-300 ${
        isVisible ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
      }`}
      style={{ backdropFilter: 'blur(12px)' }}
    >
      {icons[toast.type]}
      <div className="flex-1">
        <p className="font-medium text-[var(--text-primary)]">{toast.title}</p>
        {toast.message && (
          <p className="text-sm text-[var(--text-secondary)] mt-0.5">{toast.message}</p>
        )}
      </div>
      <button onClick={onClose} className="text-[var(--text-muted)] hover:text-[var(--text-primary)]">
        <X size={18} />
      </button>
    </div>
  );
}
