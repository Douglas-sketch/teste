import { useState } from 'react';
import { ArrowLeft, MapPin, User, FileText, Camera, Check, X } from 'lucide-react';
import { Profile, Relatorio, AutoInfracao } from '@/types/database';
import { 
  aprovarRelatorio, 
  devolverRelatorio, 
  aprovarAuto, 
  getFotosByDenuncia,
  updateAuto
} from '@/lib/store';

interface AprovarItemProps {
  user: Profile;
  tipo: 'relatorio' | 'auto';
  relatorio?: Relatorio;
  auto?: AutoInfracao;
  onBack: () => void;
}

export function AprovarItem({ tipo, relatorio, auto, onBack }: AprovarItemProps) {
  const [parecer, setParecer] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const item = tipo === 'relatorio' ? relatorio : auto;
  const denuncia = item?.denuncia;
  const fiscal = item?.fiscal;

  const fotosVistoria = denuncia ? getFotosByDenuncia(denuncia.id, 'vistoria') : [];
  const fotosRelatorio = denuncia ? getFotosByDenuncia(denuncia.id, 'relatorio') : [];
  const fotosAuto = denuncia ? getFotosByDenuncia(denuncia.id, 'auto_infracao') : [];
  const fotos = [...fotosVistoria, ...fotosRelatorio, ...fotosAuto];

  const handleAprovar = async () => {
    setSubmitting(true);
    await new Promise(r => setTimeout(r, 500));
    
    if (tipo === 'relatorio' && relatorio) {
      aprovarRelatorio(relatorio.id, parecer);
    } else if (tipo === 'auto' && auto) {
      aprovarAuto(auto.id, parecer);
    }
    
    setSubmitting(false);
    onBack();
  };

  const handleDevolver = async () => {
    if (!parecer.trim()) {
      alert('Por favor, informe o motivo da devolução');
      return;
    }
    
    setSubmitting(true);
    await new Promise(r => setTimeout(r, 500));
    
    if (tipo === 'relatorio' && relatorio) {
      devolverRelatorio(relatorio.id, parecer);
    } else if (tipo === 'auto' && auto) {
      updateAuto(auto.id, { status_aprovacao: 'devolvido', gerente_parecer: parecer });
    }
    
    setSubmitting(false);
    onBack();
  };

  if (!item || !denuncia) {
    return null;
  }

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-[var(--text-secondary)]">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-lg font-semibold text-[var(--text-primary)]">
              {tipo === 'relatorio' ? 'Revisar Relatório' : 'Aprovar Auto'}
            </h1>
            <p className="text-sm text-[var(--text-secondary)]">{denuncia.protocolo}</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4 pb-40">
        {/* Denuncia Info */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)] space-y-2">
          <div className="flex items-start gap-2">
            <FileText size={16} className="text-[var(--text-muted)] mt-0.5" />
            <div>
              <span className="text-sm text-[var(--text-secondary)]">Tipo: </span>
              <span className="text-[var(--text-primary)]">{denuncia.tipo}</span>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <MapPin size={16} className="text-[var(--text-muted)] mt-0.5" />
            <div>
              <span className="text-sm text-[var(--text-secondary)]">Local: </span>
              <span className="text-[var(--text-primary)]">{denuncia.endereco}</span>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <User size={16} className="text-[var(--text-muted)] mt-0.5" />
            <div>
              <span className="text-sm text-[var(--text-secondary)]">Fiscal: </span>
              <span className="text-[var(--text-primary)]">{fiscal?.nome}</span>
            </div>
          </div>
        </div>

        {/* Relatório Content */}
        {tipo === 'relatorio' && relatorio && (
          <>
            <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
              <h3 className="text-sm text-[var(--text-secondary)] mb-2">Tipo de Relatório</h3>
              <p className="text-[var(--text-primary)] font-medium">{relatorio.tipo_relatorio}</p>
            </div>

            <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
              <h3 className="text-sm text-[var(--text-secondary)] mb-2">Situação Encontrada</h3>
              <p className="text-[var(--text-primary)]">{relatorio.situacao_encontrada}</p>
            </div>

            <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
              <h3 className="text-sm text-[var(--text-secondary)] mb-2">Providências Adotadas</h3>
              <p className="text-[var(--text-primary)]">{relatorio.providencias_adotadas}</p>
            </div>

            {relatorio.observacoes && (
              <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
                <h3 className="text-sm text-[var(--text-secondary)] mb-2">Observações</h3>
                <p className="text-[var(--text-primary)]">{relatorio.observacoes}</p>
              </div>
            )}

            {relatorio.assinatura_url && (
              <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
                <h3 className="text-sm text-[var(--text-secondary)] mb-2">Assinatura Digital</h3>
                <img 
                  src={relatorio.assinatura_url} 
                  alt="Assinatura" 
                  className="bg-white rounded-lg p-2 max-h-24"
                />
                {relatorio.assinatura_dados && (
                  <p className="text-xs text-[var(--text-muted)] mt-2">
                    {relatorio.assinatura_dados.data} às {relatorio.assinatura_dados.hora}
                  </p>
                )}
              </div>
            )}
          </>
        )}

        {/* Auto Content */}
        {tipo === 'auto' && auto && (
          <>
            <div className="bg-[var(--bg-card)] rounded-2xl p-5 border border-[var(--border)] text-center">
              <p className="text-sm text-[var(--text-secondary)] mb-2">Valor Total da Multa</p>
              <p className="text-4xl font-bold text-[#00D4AA]">
                R$ {auto.valor_total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </p>
              <p className="text-xs text-[var(--text-muted)] mt-2">
                Base R$ {auto.valor_base.toLocaleString('pt-BR')} × {auto.grau_multiplicador}x ({auto.grau}) × {auto.reincidencia_multiplicador}x
              </p>
            </div>

            <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
              <h3 className="text-sm text-[var(--text-secondary)] mb-2">Infração</h3>
              <p className="text-[var(--text-primary)] font-medium">{auto.infracao_tipo}</p>
            </div>

            <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
              <h3 className="text-sm text-[var(--text-secondary)] mb-2">Fundamentação Legal</h3>
              <p className="text-[var(--text-primary)]">{auto.fundamento_legal}</p>
            </div>

            <div className="bg-[var(--bg-card-secondary)] rounded-xl p-3 flex items-center justify-between">
              <span className="text-sm text-[var(--text-secondary)]">Prazo para recurso</span>
              <span className="text-[var(--text-primary)] font-medium">{auto.prazo_recurso_dias} dias</span>
            </div>

            {auto.reincidencia && (
              <div className="bg-[#FF4757]/10 border border-[#FF4757]/30 rounded-xl p-3">
                <span className="text-sm text-[#FF4757] font-medium">⚠️ Infrator reincidente — Multiplicador 2x aplicado</span>
              </div>
            )}

            {auto.observacoes && (
              <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
                <h3 className="text-sm text-[var(--text-secondary)] mb-2">Observações</h3>
                <p className="text-[var(--text-primary)]">{auto.observacoes}</p>
              </div>
            )}
          </>
        )}

        {/* Fotos */}
        {fotos.length > 0 && (
          <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
            <div className="flex items-center gap-2 mb-3">
              <Camera size={16} className="text-[var(--text-muted)]" />
              <h3 className="text-sm text-[var(--text-secondary)]">Fotos anexadas</h3>
            </div>
            <div className="flex gap-2 overflow-x-auto hide-scrollbar">
              {fotos.map(foto => (
                <img 
                  key={foto.id}
                  src={foto.url}
                  alt=""
                  className="w-24 h-24 rounded-lg object-cover flex-shrink-0"
                />
              ))}
            </div>
          </div>
        )}

        {/* Parecer */}
        <div>
          <label className="text-sm text-[var(--text-secondary)] mb-2 block">
            Parecer do Gerente (obrigatório para devolver)
          </label>
          <textarea
            value={parecer}
            onChange={e => setParecer(e.target.value)}
            rows={3}
            className="w-full px-4 py-3 rounded-xl resize-none"
            placeholder="Adicione um comentário ou justificativa..."
          />
        </div>
      </div>

      {/* Footer */}
      <div className="fixed bottom-0 left-0 right-0 bg-[var(--bg-card)] border-t border-[var(--border)] p-4 safe-bottom">
        <div className="flex gap-3">
          <button
            onClick={handleDevolver}
            disabled={submitting}
            className="flex-1 py-4 rounded-xl bg-[#FF4757]/20 border border-[#FF4757]/30 font-semibold text-[#FF4757] flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <X size={20} />
            Devolver
          </button>
          <button
            onClick={handleAprovar}
            disabled={submitting}
            className="flex-1 py-4 rounded-xl bg-gradient-to-r from-[#00D4AA] to-[#00B894] font-semibold text-white flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Check size={20} />
            {submitting ? 'Aprovando...' : 'Aprovar'}
          </button>
        </div>
      </div>
    </div>
  );
}
