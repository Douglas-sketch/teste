import { useState } from 'react';
import { ArrowLeft, MapPin, User, Clock, FileText, AlertTriangle, Camera } from 'lucide-react';
import { Profile, Denuncia, Prioridade } from '@/types/database';
import { designarFiscal, getFotosByDenuncia, getHistoricoEndereco, getDenunciasByFiscal } from '@/lib/store';

interface DesignarFiscalProps {
  user: Profile;
  denuncia: Denuncia;
  fiscais: Profile[];
  onBack: () => void;
}

export function DesignarFiscal({ user, denuncia, fiscais, onBack }: DesignarFiscalProps) {
  const [prioridade, setPrioridade] = useState<Prioridade>('normal');
  const [fiscalSelecionado, setFiscalSelecionado] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const fotos = getFotosByDenuncia(denuncia.id, 'denuncia');
  const historico = getHistoricoEndereco(denuncia.endereco);

  const handleDesignar = async () => {
    if (!fiscalSelecionado) return;
    
    setSubmitting(true);
    await new Promise(r => setTimeout(r, 500));
    
    designarFiscal(denuncia.id, fiscalSelecionado, user.id, prioridade);
    
    setSubmitting(false);
    onBack();
  };

  const fiscal = fiscais.find(f => f.id === fiscalSelecionado);

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="text-[var(--text-secondary)]">
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className="text-lg font-semibold text-[var(--text-primary)]">Designar Fiscal</h1>
            <p className="text-sm text-[var(--text-secondary)]">{denuncia.protocolo}</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4 pb-32">
        {/* Denuncia Info */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)] space-y-3">
          <div className="flex items-start gap-2">
            <FileText size={16} className="text-[var(--text-muted)] mt-0.5" />
            <div>
              <span className="text-sm text-[var(--text-secondary)]">Tipo: </span>
              <span className="text-[var(--text-primary)]">{denuncia.tipo}</span>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <User size={16} className="text-[var(--text-muted)] mt-0.5" />
            <div>
              <span className="text-sm text-[var(--text-secondary)]">Denunciante: </span>
              <span className="text-[var(--text-primary)]">{denuncia.denunciante_nome}</span>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <MapPin size={16} className="text-[var(--text-muted)] mt-0.5" />
            <div>
              <span className="text-sm text-[var(--text-secondary)]">Local: </span>
              <span className="text-[var(--text-primary)]">{denuncia.endereco}</span>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Clock size={16} className="text-[var(--text-muted)] mt-0.5" />
            <div>
              <span className="text-sm text-[var(--text-secondary)]">Data: </span>
              <span className="text-[var(--text-primary)]">
                {new Date(denuncia.created_at).toLocaleDateString('pt-BR')} às {new Date(denuncia.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
        </div>

        {/* Descrição */}
        <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
          <h3 className="text-sm text-[var(--text-secondary)] mb-2">Descrição</h3>
          <p className="text-[var(--text-primary)]">{denuncia.descricao}</p>
        </div>

        {/* Fotos */}
        {fotos.length > 0 && (
          <div className="bg-[var(--bg-card)] rounded-2xl p-4 border border-[var(--border)]">
            <div className="flex items-center gap-2 mb-3">
              <Camera size={16} className="text-[var(--text-muted)]" />
              <h3 className="text-sm text-[var(--text-secondary)]">Fotos do denunciante</h3>
            </div>
            <div className="flex gap-2 overflow-x-auto hide-scrollbar">
              {fotos.map(foto => (
                <img 
                  key={foto.id}
                  src={foto.url_marca_dagua || foto.url}
                  alt=""
                  className="w-20 h-20 rounded-lg object-cover flex-shrink-0"
                />
              ))}
            </div>
          </div>
        )}

        {/* Histórico */}
        {historico.total_ocorrencias > 1 && (
          <div className="bg-[#FFB020]/10 border border-[#FFB020]/30 rounded-2xl p-4">
            <div className="flex items-center gap-2 text-[#FFB020] mb-2">
              <AlertTriangle size={18} />
              <span className="font-medium">⚠️ {historico.total_ocorrencias} ocorrências neste endereço</span>
            </div>
            <div className="space-y-1">
              {historico.protocolos.slice(0, 3).filter(p => p !== denuncia.protocolo).map((prot, i) => (
                <p key={prot} className="text-sm text-[var(--text-secondary)]">
                  {prot} — {historico.tipos[i]} — {new Date(historico.datas[i]).toLocaleDateString('pt-BR')}
                </p>
              ))}
            </div>
          </div>
        )}

        {/* Prioridade */}
        <div>
          <h3 className="text-sm text-[var(--text-secondary)] mb-3">Definir Prioridade</h3>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setPrioridade('normal')}
              className={`py-4 rounded-xl border text-center transition-all ${
                prioridade === 'normal' 
                  ? 'bg-[#00D4AA]/20 border-[#00D4AA] text-[#00D4AA]' 
                  : 'bg-[var(--bg-card)] border-[var(--border)] text-[var(--text-primary)]'
              }`}
            >
              <span className="text-2xl">🟢</span>
              <p className="font-medium mt-1">Normal</p>
              <p className="text-xs opacity-70">7 dias</p>
            </button>
            <button
              onClick={() => setPrioridade('alta')}
              className={`py-4 rounded-xl border text-center transition-all ${
                prioridade === 'alta' 
                  ? 'bg-[#FFB020]/20 border-[#FFB020] text-[#FFB020]' 
                  : 'bg-[var(--bg-card)] border-[var(--border)] text-[var(--text-primary)]'
              }`}
            >
              <span className="text-2xl">🟡</span>
              <p className="font-medium mt-1">Alta</p>
              <p className="text-xs opacity-70">3 dias</p>
            </button>
            <button
              onClick={() => setPrioridade('urgente')}
              className={`py-4 rounded-xl border text-center transition-all ${
                prioridade === 'urgente' 
                  ? 'bg-[#FF4757]/20 border-[#FF4757] text-[#FF4757]' 
                  : 'bg-[var(--bg-card)] border-[var(--border)] text-[var(--text-primary)]'
              }`}
            >
              <span className="text-2xl">🔴</span>
              <p className="font-medium mt-1">Urgente</p>
              <p className="text-xs opacity-70">24h</p>
            </button>
          </div>
        </div>

        {/* Escolher Fiscal */}
        <div>
          <h3 className="text-sm text-[var(--text-secondary)] mb-3">Escolher Fiscal</h3>
          <div className="space-y-2">
            {fiscais.map(f => {
              const ativas = getDenunciasByFiscal(f.id).filter(d => ['designada', 'em_vistoria'].includes(d.status)).length;
              
              return (
                <button
                  key={f.id}
                  onClick={() => setFiscalSelecionado(f.id)}
                  className={`w-full p-4 rounded-xl border flex items-center gap-3 transition-all ${
                    fiscalSelecionado === f.id 
                      ? 'bg-[#00D4AA]/10 border-[#00D4AA]' 
                      : 'bg-[var(--bg-card)] border-[var(--border)]'
                  }`}
                >
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold"
                    style={{ backgroundColor: f.avatar_color }}
                  >
                    {f.avatar_initials}
                  </div>
                  <div className="flex-1 text-left">
                    <p className="font-medium text-[var(--text-primary)]">{f.nome}</p>
                    <p className="text-sm text-[var(--text-secondary)]">
                      {f.matricula} • {ativas} ativa(s)
                    </p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${
                    f.status_online === 'em_campo' ? 'bg-[#00D4AA]' : 
                    f.status_online === 'escritorio' ? 'bg-[#FFB020]' : 'bg-[var(--text-muted)]'
                  }`} />
                  {fiscalSelecionado === f.id && (
                    <div className="w-6 h-6 rounded-full bg-[#00D4AA] flex items-center justify-center">
                      <span className="text-white text-sm">✓</span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="fixed bottom-0 left-0 right-0 bg-[var(--bg-card)] border-t border-[var(--border)] p-4 safe-bottom">
        <button
          onClick={handleDesignar}
          disabled={!fiscalSelecionado || submitting}
          className="w-full py-4 rounded-xl bg-gradient-to-r from-[#00D4AA] to-[#00B894] font-semibold text-white disabled:opacity-50"
        >
          {submitting ? 'Designando...' : `Designar ${fiscal?.nome.split(' ')[0] || 'Fiscal'}`}
        </button>
      </div>
    </div>
  );
}
