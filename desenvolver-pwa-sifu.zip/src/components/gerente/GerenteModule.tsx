import { useState, useEffect } from 'react';
import { LogOut, Bell, Users, Clock, CheckCircle, AlertTriangle, ChevronRight, FileText, Scale, MapPin } from 'lucide-react';
import { Profile, Denuncia, Relatorio, AutoInfracao } from '@/types/database';
import { 
  getDashboardStats, 
  getDenunciasPendentes, 
  getDenunciasAguardandoAprovacao,
  getRelatoriosPendentes,
  getAutosPendentes,
  getFiscais,
  getDenunciasByFiscal,
  getUnreadCount,
  subscribe 
} from '@/lib/store';
import { DesignarFiscal } from './DesignarFiscal';
import { AprovarItem } from './AprovarItem';
import { NotificacoesView } from '../fiscal/NotificacoesView';

interface GerenteModuleProps {
  user: Profile;
  onLogout: () => void;
}

type Screen = 'home' | 'designar' | 'aprovar-relatorio' | 'aprovar-auto' | 'notificacoes';
type Tab = 'pendentes' | 'aguardando' | 'equipe';

export function GerenteModule({ user, onLogout }: GerenteModuleProps) {
  const [screen, setScreen] = useState<Screen>('home');
  const [tab, setTab] = useState<Tab>('pendentes');
  const [stats, setStats] = useState({ pendentes: 0, em_andamento: 0, concluidas: 0, aguardando_aprovacao: 0 });
  const [pendentes, setPendentes] = useState<Denuncia[]>([]);
  const [relatoriosPendentes, setRelatoriosPendentes] = useState<Relatorio[]>([]);
  const [autosPendentes, setAutosPendentes] = useState<AutoInfracao[]>([]);
  const [fiscais, setFiscais] = useState<Profile[]>([]);
  const [selectedDenuncia, setSelectedDenuncia] = useState<Denuncia | null>(null);
  const [selectedRelatorio, setSelectedRelatorio] = useState<Relatorio | null>(null);
  const [selectedAuto, setSelectedAuto] = useState<AutoInfracao | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    loadData();
    const unsubscribe = subscribe('*', loadData);
    return () => { unsubscribe(); };
  }, [user.id]);

  const loadData = () => {
    setStats(getDashboardStats());
    setPendentes(getDenunciasPendentes());
    setRelatoriosPendentes(getRelatoriosPendentes());
    setAutosPendentes(getAutosPendentes());
    setFiscais(getFiscais());
    setUnreadCount(getUnreadCount(user.id));
  };

  // Calculate time since creation
  const getTimeSince = (date: string) => {
    const hours = Math.floor((Date.now() - new Date(date).getTime()) / (1000 * 60 * 60));
    if (hours < 1) return 'Agora';
    if (hours < 24) return `${hours}h`;
    return `${Math.floor(hours / 24)}d`;
  };

  // Get urgency class
  const getUrgencyClass = (date: string) => {
    const hours = (Date.now() - new Date(date).getTime()) / (1000 * 60 * 60);
    if (hours > 12) return 'border-[#FF4757] bg-[#FF4757]/5';
    if (hours > 4) return 'border-[#FFB020] bg-[#FFB020]/5';
    return 'border-[var(--border)]';
  };

  if (screen === 'notificacoes') {
    return <NotificacoesView user={user} onBack={() => setScreen('home')} />;
  }

  if (screen === 'designar' && selectedDenuncia) {
    return (
      <DesignarFiscal 
        user={user}
        denuncia={selectedDenuncia}
        fiscais={fiscais}
        onBack={() => { setScreen('home'); setSelectedDenuncia(null); loadData(); }}
      />
    );
  }

  if (screen === 'aprovar-relatorio' && selectedRelatorio) {
    return (
      <AprovarItem 
        user={user}
        tipo="relatorio"
        relatorio={selectedRelatorio}
        onBack={() => { setScreen('home'); setSelectedRelatorio(null); loadData(); }}
      />
    );
  }

  if (screen === 'aprovar-auto' && selectedAuto) {
    return (
      <AprovarItem 
        user={user}
        tipo="auto"
        auto={selectedAuto}
        onBack={() => { setScreen('home'); setSelectedAuto(null); loadData(); }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {/* Header */}
      <div className="bg-[var(--bg-card)] border-b border-[var(--border)] px-4 py-4 safe-top">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold"
              style={{ backgroundColor: user.avatar_color }}
            >
              {user.avatar_initials}
            </div>
            <div>
              <h1 className="font-semibold text-[var(--text-primary)]">Painel Gerencial</h1>
              <p className="text-sm text-[var(--text-secondary)]">{user.nome}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setScreen('notificacoes')}
              className="relative w-10 h-10 rounded-full bg-[var(--bg-card-secondary)] flex items-center justify-center"
            >
              <Bell size={20} className="text-[var(--text-secondary)]" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#FF4757] text-white text-xs flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </button>
            <button 
              onClick={onLogout}
              className="w-10 h-10 rounded-full bg-[var(--bg-card-secondary)] flex items-center justify-center"
            >
              <LogOut size={20} className="text-[var(--text-secondary)]" />
            </button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="p-4 pb-0">
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-[#FF4757]/10 rounded-xl p-4 text-center border border-[#FF4757]/30">
            <p className="text-2xl font-bold text-[#FF4757]">{stats.pendentes}</p>
            <p className="text-xs text-[var(--text-secondary)]">Pendentes</p>
          </div>
          <div className="bg-[#FFB020]/10 rounded-xl p-4 text-center border border-[#FFB020]/30">
            <p className="text-2xl font-bold text-[#FFB020]">{stats.em_andamento}</p>
            <p className="text-xs text-[var(--text-secondary)]">Em andamento</p>
          </div>
          <div className="bg-[#00D4AA]/10 rounded-xl p-4 text-center border border-[#00D4AA]/30">
            <p className="text-2xl font-bold text-[#00D4AA]">{stats.concluidas}</p>
            <p className="text-xs text-[var(--text-secondary)]">Concluídas</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 pt-4">
        <div className="flex gap-2 bg-[var(--bg-card)] rounded-xl p-1">
          <button
            onClick={() => setTab('pendentes')}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === 'pendentes' 
                ? 'bg-[#FF4757] text-white' 
                : 'text-[var(--text-secondary)]'
            }`}
          >
            Pendentes
            {pendentes.length > 0 && (
              <span className="ml-1 px-1.5 py-0.5 rounded-full bg-white/20 text-xs">
                {pendentes.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setTab('aguardando')}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === 'aguardando' 
                ? 'bg-[#8B5CF6] text-white' 
                : 'text-[var(--text-secondary)]'
            }`}
          >
            Aprovação
            {(relatoriosPendentes.length + autosPendentes.length) > 0 && (
              <span className="ml-1 px-1.5 py-0.5 rounded-full bg-white/20 text-xs">
                {relatoriosPendentes.length + autosPendentes.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setTab('equipe')}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === 'equipe' 
                ? 'bg-[#00D4AA] text-white' 
                : 'text-[var(--text-secondary)]'
            }`}
          >
            Equipe
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        {/* TAB: Pendentes */}
        {tab === 'pendentes' && (
          <>
            {pendentes.length === 0 ? (
              <div className="bg-[#00D4AA]/10 border border-[#00D4AA]/30 rounded-2xl p-6 text-center">
                <CheckCircle className="mx-auto mb-2 text-[#00D4AA]" size={32} />
                <p className="text-[#00D4AA] font-medium">✅ Tudo designado!</p>
                <p className="text-sm text-[var(--text-secondary)]">Nenhuma denúncia aguardando designação</p>
              </div>
            ) : (
              pendentes.map(denuncia => (
                <button
                  key={denuncia.id}
                  onClick={() => { setSelectedDenuncia(denuncia); setScreen('designar'); }}
                  className={`w-full bg-[var(--bg-card)] rounded-xl p-4 border text-left transition-all ${getUrgencyClass(denuncia.created_at)}`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="font-semibold text-[var(--text-primary)]">{denuncia.protocolo}</p>
                      <span className="badge badge-pendente">Pendente</span>
                    </div>
                    <div className="flex items-center gap-1 text-sm text-[var(--text-muted)]">
                      <Clock size={14} />
                      <span>{getTimeSince(denuncia.created_at)}</span>
                    </div>
                  </div>
                  <p className="text-sm text-[var(--text-primary)] mb-1">{denuncia.tipo}</p>
                  <div className="flex items-center gap-1 text-sm text-[var(--text-secondary)]">
                    <MapPin size={14} />
                    <span className="truncate">{denuncia.endereco}</span>
                  </div>
                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-[var(--border)]">
                    <span className="text-xs text-[var(--text-secondary)]">
                      Denunciante: {denuncia.denunciante_nome}
                    </span>
                    <span className="text-[#00D4AA] text-sm font-medium flex items-center gap-1">
                      Designar <ChevronRight size={16} />
                    </span>
                  </div>
                </button>
              ))
            )}
          </>
        )}

        {/* TAB: Aguardando Aprovação */}
        {tab === 'aguardando' && (
          <>
            {relatoriosPendentes.length === 0 && autosPendentes.length === 0 ? (
              <div className="bg-[var(--bg-card)] border border-[var(--border)] rounded-2xl p-6 text-center">
                <FileText className="mx-auto mb-2 text-[var(--text-muted)]" size={32} />
                <p className="text-[var(--text-secondary)]">Nenhum item aguardando aprovação</p>
              </div>
            ) : (
              <>
                {relatoriosPendentes.map(relatorio => (
                  <button
                    key={relatorio.id}
                    onClick={() => { setSelectedRelatorio(relatorio); setScreen('aprovar-relatorio'); }}
                    className="w-full bg-[var(--bg-card)] rounded-xl p-4 border border-[var(--border)] text-left"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-semibold text-[var(--text-primary)]">{relatorio.denuncia?.protocolo}</p>
                        <span className="badge badge-aguardando">Relatório</span>
                      </div>
                      <FileText size={20} className="text-[#8B5CF6]" />
                    </div>
                    <p className="text-sm text-[var(--text-primary)]">{relatorio.tipo_relatorio}</p>
                    <p className="text-sm text-[var(--text-secondary)] truncate">{relatorio.denuncia?.endereco}</p>
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-[var(--border)]">
                      <span className="text-xs text-[var(--text-secondary)]">
                        Fiscal: {relatorio.fiscal?.nome}
                      </span>
                      <span className="text-[#8B5CF6] text-sm font-medium flex items-center gap-1">
                        Revisar <ChevronRight size={16} />
                      </span>
                    </div>
                  </button>
                ))}
                {autosPendentes.map(auto => (
                  <button
                    key={auto.id}
                    onClick={() => { setSelectedAuto(auto); setScreen('aprovar-auto'); }}
                    className="w-full bg-[var(--bg-card)] rounded-xl p-4 border border-[var(--border)] text-left"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-semibold text-[var(--text-primary)]">{auto.denuncia?.protocolo}</p>
                        <span className="badge badge-urgente">Auto de Infração</span>
                      </div>
                      <Scale size={20} className="text-[#FF4757]" />
                    </div>
                    <p className="text-lg font-bold text-[#00D4AA]">
                      R$ {auto.valor_total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </p>
                    <p className="text-sm text-[var(--text-secondary)]">{auto.infracao_tipo}</p>
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-[var(--border)]">
                      <span className="text-xs text-[var(--text-secondary)]">
                        Fiscal: {auto.fiscal?.nome}
                      </span>
                      <span className="text-[#FF4757] text-sm font-medium flex items-center gap-1">
                        Aprovar <ChevronRight size={16} />
                      </span>
                    </div>
                  </button>
                ))}
              </>
            )}
          </>
        )}

        {/* TAB: Equipe */}
        {tab === 'equipe' && (
          <div className="space-y-3">
            {fiscais.map(fiscal => {
              const denunciasFiscal = getDenunciasByFiscal(fiscal.id);
              const ativas = denunciasFiscal.filter(d => ['designada', 'em_vistoria'].includes(d.status)).length;
              
              return (
                <div
                  key={fiscal.id}
                  className="bg-[var(--bg-card)] rounded-xl p-4 border border-[var(--border)]"
                >
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-12 h-12 rounded-full flex items-center justify-center text-white font-semibold"
                      style={{ backgroundColor: fiscal.avatar_color }}
                    >
                      {fiscal.avatar_initials}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-[var(--text-primary)]">{fiscal.nome}</p>
                      <p className="text-sm text-[var(--text-secondary)]">{fiscal.matricula}</p>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${
                      fiscal.status_online === 'em_campo' ? 'bg-[#00D4AA]' : 
                      fiscal.status_online === 'escritorio' ? 'bg-[#FFB020]' : 'bg-[var(--text-muted)]'
                    }`} />
                  </div>
                  <div className="mt-3 pt-3 border-t border-[var(--border)] flex items-center justify-between">
                    <span className="text-sm text-[var(--text-secondary)]">
                      {fiscal.status_online === 'em_campo' ? '● Em campo' : 
                       fiscal.status_online === 'escritorio' ? '● No escritório' : '● Offline'}
                    </span>
                    <span className="text-sm text-[var(--text-primary)]">
                      {ativas} denúncia(s) ativa(s)
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
