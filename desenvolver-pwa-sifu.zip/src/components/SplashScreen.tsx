import { useState, useEffect } from 'react';
import { Shield } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const duration = 2500;
    const interval = 50;
    const increment = (100 / duration) * interval;

    const timer = setInterval(() => {
      setProgress(prev => {
        const next = prev + increment;
        if (next >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 200);
          return 100;
        }
        return next;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-[#101D3D]">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#101D3D] via-[#1B2D52] to-[#101D3D] opacity-50" />
      
      {/* Content */}
      <div className="relative z-10 flex flex-col items-center">
        {/* Shield Icon */}
        <div className="relative mb-6">
          <div className="absolute inset-0 bg-[#00D4AA] blur-2xl opacity-30 animate-pulse" />
          <div className="relative w-24 h-24 bg-gradient-to-br from-[#00D4AA] to-[#00B894] rounded-2xl flex items-center justify-center shadow-2xl">
            <Shield className="w-14 h-14 text-white" strokeWidth={1.5} />
          </div>
        </div>

        {/* SIFU Logo */}
        <h1 className="text-5xl font-bold mb-2 tracking-tight">
          <span className="text-white">SI</span>
          <span className="text-[#00D4AA]">FU</span>
        </h1>

        {/* Subtitle */}
        <p className="text-[#8B9DC3] text-sm mb-12 tracking-wide">
          Fiscalização Urbana
        </p>

        {/* Progress Bar */}
        <div className="w-48 h-1 bg-[#1B2D52] rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-[#00D4AA] to-[#00B894] transition-all duration-100 ease-out rounded-full"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Footer */}
        <p className="absolute bottom-8 text-[#5A6F96] text-xs text-center px-8">
          Prefeitura do Cabo de Santo Agostinho — v2.1
        </p>
      </div>
    </div>
  );
}
