import { useState, useEffect } from 'react';
import { SplashScreen } from '@/components/SplashScreen';
import { ProfileSelection } from '@/components/ProfileSelection';
import { CidadaoModule } from '@/components/cidadao/CidadaoModule';
import { FiscalModule } from '@/components/fiscal/FiscalModule';
import { GerenteModule } from '@/components/gerente/GerenteModule';
import { getCurrentUser, setCurrentUser, subscribe } from '@/lib/store';
import { Profile } from '@/types/database';

type AppScreen = 'splash' | 'profile-selection' | 'cidadao' | 'fiscal' | 'gerente';

export function App() {
  const [screen, setScreen] = useState<AppScreen>('splash');
  const [currentUser, setCurrentUserState] = useState<Profile | null>(null);

  useEffect(() => {
    // Check for existing session
    const user = getCurrentUser();
    if (user) {
      setCurrentUserState(user);
      setScreen(user.tipo === 'fiscal' ? 'fiscal' : user.tipo === 'gerente' ? 'gerente' : 'cidadao');
    }

    // Subscribe to user changes
    const unsubscribe = subscribe('sifu_current_user', () => {
      const updatedUser = getCurrentUser();
      setCurrentUserState(updatedUser);
    });

    return () => { unsubscribe(); };
  }, []);

  const handleSplashComplete = () => {
    const user = getCurrentUser();
    if (user) {
      setScreen(user.tipo === 'fiscal' ? 'fiscal' : user.tipo === 'gerente' ? 'gerente' : 'cidadao');
    } else {
      setScreen('profile-selection');
    }
  };

  const handleProfileSelect = (profile: 'cidadao' | 'fiscal' | 'gerente', user?: Profile) => {
    if (user) {
      setCurrentUser(user);
      setCurrentUserState(user);
    }
    setScreen(profile);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentUserState(null);
    setScreen('profile-selection');
  };

  const handleBack = () => {
    setScreen('profile-selection');
  };

  return (
    <div className="min-h-screen bg-[var(--bg-primary)]">
      {screen === 'splash' && (
        <SplashScreen onComplete={handleSplashComplete} />
      )}
      
      {screen === 'profile-selection' && (
        <ProfileSelection onSelect={handleProfileSelect} />
      )}
      
      {screen === 'cidadao' && (
        <CidadaoModule onBack={handleBack} />
      )}
      
      {screen === 'fiscal' && currentUser && (
        <FiscalModule user={currentUser} onLogout={handleLogout} />
      )}
      
      {screen === 'gerente' && currentUser && (
        <GerenteModule user={currentUser} onLogout={handleLogout} />
      )}
    </div>
  );
}
